import {createCurvedEaveRafter} from './scene03-curved-rafter.js';
import {createCarvedReceivers106} from './scene03-carved-receivers106.js';
import {createSculptedTimber109} from './scene03-sculpted-timber109.js';
import {createBearing174} from './scene03-bearing174.js';

//109 replaces thin separated ranks with an occupied, stepped bearing canopy.
// All altered cross-sections, carved noses, cups, girts and returns are actual
// closed wood; the retained outer roof surface and site/camera are not moved.
export function buildHallCarpentry03(T,api){
 const {C,emit,box,grouped,role,mats,upper,lin,tube}=api,axes=[-5.70,-3.80,-1.90,0,1.90,3.80,5.70],wallZ=-1.10;
 const owned=new Set(),keep=g=>{owned.add(g);return g;},carvedReceivers=createCarvedReceivers106(T,{emit,keep}),carving=createSculptedTimber109(T,keep);
 const curved=(points,w,h,ma='cedar')=>emit(keep(createCurvedEaveRafter(points,w,h)),ma);
 const bearing174=createBearing174(T,{emit,grouped,keep}),cluster=bearing174.cluster;
 const seat=(x,z)=>{const t=(z-C.ridgeZ)/5.2,u=x/(api.upperWidth*(.275+.225*t));return upper.P(0,t,u)[1]-.30;},curveAt=(y,x,z)=>y+seat(x,z)-seat(0,z);
 function girt(y,z,half=6.03,w=.46,h=.31,ma='red'){curved(lin(-half,half,72).map(x=>[x,curveAt(y,x,z),z]),w,h,ma);}
 role('upper-compressed-deep-gallery109',()=>{
  // Short enclosed gallery and thick top rail carry the expanded capitals.
  box(0,11.66,wallZ-.20,12.02,1.18,.38,'darkwood');
  for(const sign of[-1,1])box(sign*5.94,11.66,-4.50,.34,1.18,7.1,'darkwood');
  box(0,11.66,-8.0,12.02,1.18,.34,'darkwood');
  for(const[y,h]of[[11.14,.25],[11.96,.22],[12.22,.34]])girt(y,wallZ+.04,6.06,.49,h,'red');
  for(let i=0;i<axes.length-1;i++){
   const x=(axes[i]+axes[i+1])/2,w=axes[i+1]-axes[i]-.48;
   box(x,11.59,wallZ-.025,w,.39,.17,'roofFrieze');
   for(const sign of[-1,1])box(x,11.59+sign*.23,wallZ+.09,w+.08,.075,.11,'cedar');
   for(let j=1;j<8;j++)box(x-w/2+w*j/8,11.98,wallZ+.005,.050,.32,.15,'cedar');
   for(const sign of[-1,1])box(x+sign*(w/2+.03),11.65,wallZ+.085,.09,.73,.20,'red');
   carvedReceivers.face(x,11.61,wallZ+.15,.40,.28,.44);
  }
  for(const x of axes){
   box(x,11.68,wallZ+.10,.43,1.30,.55,'red');
   emit(carving.scrollFace(1),'darkwood',x,11.65,wallZ+.39,.29,.73,.15);
   for(const sign of[-1,1])tube([[x,11.36,wallZ+.435],[x+sign*.10,11.48,wallZ+.46],[x+sign*.08,11.70,wallZ+.46],[x,11.91,wallZ+.435]],.016,'oldgold',24);
  }
  for(const y of[11.15,11.42])girt(y,-.36,6.04,.15,.12,'red');
  for(let i=0;i<=34;i++)box(-5.96+i*11.92/34,11.28,-.36,.065,.40,.10,'red');
 });
 role('upper-occupied-four-rank-bearing-canopy109',()=>{
  // Rear diaphragm, girts and the front/rear arm depths create one shadow
  // canopy. No new outer roof or camera contour is introduced.
  for(let i=0;i<axes.length-1;i++)box((axes[i]+axes[i+1])/2,12.82,-1.48,1.72,1.38,.25,'darkwood');
  for(const[y,z,w,h]of[[12.25,-.94,.58,.34],[13.04,-.86,.43,.32],[14.12,.45,.39,.27]])girt(y,z,6.05,w,h,'red');
  for(const x of axes)cluster(x,curveAt(12.25,x,-.95),-.95,seat(x,.64)-.13,1.05,true,1.03);
  for(let i=0;i<axes.length-1;i++){
   const x=(axes[i]+axes[i+1])/2;cluster(x,curveAt(12.94,x,-1.01),-1.01,seat(x,.56)-.16,.67,false,.88);
  }
  for(let j=0;j<=80;j++){
   const u=-1+2*j/80;
   curved(lin(.34,1.115,18).map(t=>{const p=upper.P(0,t,u);p[1]-=.32;return p;}),.14,.22,'cedar');
   curved(lin(.76,1.13,12).map(t=>{const p=upper.P(0,t,u);p[1]-=.56;return p;}),.12,.17,'red');
  }
  for(const t of[.51,.68,.84,1.0])curved(lin(-1,1,80).map(u=>{const p=upper.P(0,t,u);p[1]-=.39;return p;}),.35,.25,'cedar');
 });
 return{axes,get bearingSets(){return bearing174.instances;},bearingSeats174:bearing174.seats,get carvedReceiverFaces(){return carvedReceivers.count;},get deepCarvedNoses(){return 0;},bearingCluster:cluster,wallClosed:true,construction:bearing174.construction,dispose(){for(const g of owned)g.dispose();}};
}
