import {createCurvedEaveRafter} from './scene03-curved-rafter.js';

// A load assembly, not a stack of ornamental beam-end plates. The two
// lowest arms have complementary half laps. Successive cups sit on real
// shoulders; two deep raking tails carry the forward purlin into the column.
// Dimensions are local building metres before the explicit bearing-gap fit.
export function createBearing174(T,{emit,grouped,keep=g=>g}){
 const prototypes=[],seats=[];let instances=0;
 const own=g=>{prototypes.push(g);return keep(g);};
 function finish(g,name){
  const p=g.attributes.position,ids=g.index?Array.from(g.index.array):Array.from({length:p.count},(_,i)=>i);let volume=0;
  for(let i=0;i<ids.length;i+=3){const a=new T.Vector3().fromBufferAttribute(p,ids[i]),b=new T.Vector3().fromBufferAttribute(p,ids[i+1]),c=new T.Vector3().fromBufferAttribute(p,ids[i+2]);volume+=a.dot(b.cross(c))/6;}
  if(volume<0){for(let i=0;i<ids.length;i+=3)[ids[i+1],ids[i+2]]=[ids[i+2],ids[i+1]];g.setIndex(ids);}
  g.name=name;g.userData={authoredClosedTimber174:true,photoTexture:false,signedVolumeMetres3:Math.abs(volume)};g.computeVertexNormals();g.computeBoundingBox();g.computeBoundingSphere();return own(g);
 }
 function arm(length,depth,{lap='',rank=0}={}){
  const a=length/2,s=new T.Shape(),top=x=>.17+.055*(Math.abs(x)/a)**7,bottom=x=>-.205+.275*(Math.abs(x)/a)**1.8-.047*Math.exp(-(((Math.abs(x)/a-.70)/.17)**2));
  const xs=Array.from({length:49},(_,i)=>-a+length*i/48),cut=.225;
  const topXs=[...new Set([...xs,-cut,cut])].sort((x,y)=>x-y);
  s.moveTo(-a,top(-a));
  for(const x of topXs.slice(1)){
   if(lap==='top'&&x===-cut){s.lineTo(x,top(x));s.lineTo(x,.005);}
   else if(lap==='top'&&x===cut){s.lineTo(x,.005);s.lineTo(x,top(x));}
   else s.lineTo(x,lap==='top'&&Math.abs(x)<cut?.005:top(x));
  }
  s.lineTo(a,bottom(a));
  for(const x of topXs.slice(0,-1).reverse()){
   if(lap==='bottom'&&x===cut){s.lineTo(x,bottom(x));s.lineTo(x,.005);}
   else if(lap==='bottom'&&x===-cut){s.lineTo(x,.005);s.lineTo(x,bottom(x));}
   else s.lineTo(x,lap==='bottom'&&Math.abs(x)<cut?.005:bottom(x));
  }
  s.closePath();
  const g=new T.ExtrudeGeometry(s,{depth,steps:6,bevelEnabled:true,bevelSize:.008,bevelThickness:.008,bevelSegments:3,curveSegments:24}),p=g.attributes.position;
  for(let i=0;i<p.count;i++){
   const x=p.getX(i),y=p.getY(i),u=Math.min(1,Math.abs(x)/a),v=T.MathUtils.clamp((y+.22)/.45,0,1),z=p.getZ(i)-depth/2;
   // The belly is canted, the throats waisted, and the noses swell again.
   const cheek=(.88+.12*v)*(1-.18*Math.exp(-(((u-.62)/.19)**2)));
   p.setZ(i,z*cheek+.0035*Math.sin(x*14+rank*.73)*Math.sin(v*Math.PI));
  }
  return finish(g,'scene03-notched-canted-load-arm174-'+rank+'-'+lap);
 }
 function cup(width,height){
  const N=48,R=12,p=[],uv=[],ids=[];
  for(let j=0;j<=R;j++){const t=j/R,r=width/2*(.63+.37*Math.sin(t*Math.PI/2));for(let k=0;k<N;k++){const a=k/N*Math.PI*2,c=Math.cos(a),s=Math.sin(a);p.push(r*Math.sign(c)*Math.abs(c)**.34,height*t,r*Math.sign(s)*Math.abs(s)**.34);uv.push(k/N,t);}}
  for(let j=0;j<R;j++)for(let k=0;k<N;k++){const a=j*N+k,b=j*N+(k+1)%N;ids.push(a,b,a+N,b,b+N,a+N);}
  const c=p.length/3;p.push(0,0,0,0,height,0);uv.push(.5,0,.5,1);for(let k=0;k<N;k++)ids.push(c,(k+1)%N,k,c+1,R*N+k,R*N+(k+1)%N);
  const g=new T.BufferGeometry();g.setAttribute('position',new T.Float32BufferAttribute(p,3));g.setAttribute('uv',new T.Float32BufferAttribute(uv,2));g.setIndex(ids);return finish(g,'scene03-flared-bearing-cup174-'+width);
 }
 function tail(){
  const curve=new T.CatmullRomCurve3([[0,.29,-.34],[0,.49,-.04],[0,.91,.48],[0,1.46,1.02],[0,1.83,1.49]].map(p=>new T.Vector3(...p))),R=48,N=32,p=[],uv=[],ids=[];
  for(let j=0;j<=R;j++){
   const t=j/R,c=curve.getPoint(t),tan=curve.getTangent(t).normalize(),side=new T.Vector3(1,0,0),up=tan.clone().cross(side).normalize();
   const w=.31*(.82+.18*Math.sin(Math.PI*t)),h=.32*(1-.30*t)+.055*Math.sin(Math.PI*t);
   for(let k=0;k<N;k++){const a=k/N*Math.PI*2,ca=Math.cos(a),sa=Math.sin(a),q=c.clone().addScaledVector(side,w/2*Math.sign(ca)*Math.abs(ca)**.37).addScaledVector(up,h/2*Math.sign(sa)*Math.abs(sa)**.37);p.push(...q.toArray());uv.push(k/N,t*curve.getLength());}
  }
  for(let j=0;j<R;j++)for(let k=0;k<N;k++){const a=j*N+k,b=j*N+(k+1)%N;ids.push(a,b,a+N,b,b+N,a+N);}
  const c=p.length/3;p.push(...curve.getPoint(0).toArray(),...curve.getPoint(1).toArray());uv.push(.5,0,.5,1);for(let k=0;k<N;k++)ids.push(c,(k+1)%N,k,c+1,R*N+k,R*N+(k+1)%N);
  const g=new T.BufferGeometry();g.setAttribute('position',new T.Float32BufferAttribute(p,3));g.setAttribute('uv',new T.Float32BufferAttribute(uv,2));g.setIndex(ids);return finish(g,'scene03-closed-raking-cantilever-tail174');
 }
 const cups=[cup(.88,.26),cup(.47,.22),cup(.42,.20)],arms=[arm(1.39,.47,{lap:'top',rank:0}),arm(1.39,.47,{lap:'bottom',rank:1}),arm(1.80,.43,{rank:2}),arm(1.66,.42,{rank:3}),arm(2.10,.46,{rank:4}),arm(1.47,.39,{rank:5})],raking=tail();
 const receiver=finish(createCurvedEaveRafter([[-1.12,1.97,1.43],[0,1.95,1.43],[1.12,1.97,1.43]],.43,.22),'scene03-continuous-cambered-roof-receiver174');
 function cluster(x,base,z,top,scale=1,major=true,depthScale=scale){
  const sy=(top-base)/2.08;if(!(sy>0))throw Error('174 requires a positive occupied bearing gap');
  grouped(x,base,z,0,()=>{
   emit(cups[0],'red',0,0,0,scale,sy,depthScale);
   // The equal contact plane .455 is shared by the complementary laps.
   emit(arms[0],'cedar',0,.45*sy,0,scale,sy,depthScale);
   emit(arms[1],'red',0,.45*sy,0,depthScale,sy,scale,Math.PI/2);
   for(const sign of[-1,1]){
    emit(cups[1],'red',sign*.36*scale,.615*sy,.35*depthScale,scale,sy,depthScale);
    emit(arms[3],'cedar',sign*.36*scale,.99*sy,.39*depthScale,depthScale,sy,scale,Math.PI/2);
    emit(cups[2],'cedar',sign*.53*scale,1.205*sy,.84*depthScale,scale,sy,depthScale);
    emit(arms[5],'cedar',sign*.53*scale,1.76*sy,.96*depthScale,depthScale,sy,scale,Math.PI/2);
    // Tail bodies have continuous belly, cheeks, rounded section and caps.
    if(major)emit(raking,'red',sign*.26*scale,0,0,scale,sy,depthScale);
   }
   emit(arms[2],'red',0,1.015*sy,.36*depthScale,scale,sy,depthScale);
   emit(arms[4],'red',0,1.57*sy,.88*depthScale,scale,sy,depthScale);
   emit(receiver,'cedar',0,0,0,scale,sy,depthScale);
  });
  instances++;seats.push({column:[x,base,z],roofReceiverY:top,normalizedGap:top-base,major,sectionScale:[scale,sy,depthScale],roofOvershoot:0});
 }
 return{cluster,prototypes,seats,get instances(){return instances;},construction:'Complementary half-lapped crossed arms, flared dou, waisted canted cheeks, two continuous raking tails and one cambered purlin seat; no ornamental end plates or gold bands'};
}
