import * as T from 'three';
import {createContinuousTimber} from './gallery-joinery.js';
// Whole frame replacement: broad shaft axes, recessed window bays, deep
// connected ring beams and a compact receiving cornice under the actual roof.
export function buildGrandBearing171({emit,box,between,group,lantern,lattice,galleryJoinery,grandFrame,peony}){
 const floor=grandFrame.floor,cap=grandFrame.lintel,eave=grandFrame.eave,bw=3.50,bd=6.40,front=bd/2,xs=[-1.75,0,1.75],sideZ=[-1.60,0,1.60],beamY=8.20,caps=[];
 function shaft(x,z,r){
  const bottom=floor+.22,top=cap-.14,h=top-bottom,profile=[[0,0],[r*.98,0],[r,.10*h],[r*1.035,.38*h],[r*1.02,.62*h],[r*.96,.90*h],[r*.94,h],[0,h]],g=new T.LatheGeometry(profile.map(p=>new T.Vector2(...p)),40),p=g.attributes.position,uv=g.attributes.uv;
  for(let i=0;i<p.count;i++)uv.setXY(i,p.getY(i)/1.6,Math.atan2(p.getZ(i),p.getX(i))*r/.55);g.userData.member='171-entasis-turned-timber-shaft';
  emit(g,'red',x,bottom,z);emit(new T.CylinderGeometry(r*1.36,r*1.48,.20,32),'hallFoundation',x,floor+.10,z);box(x,cap-.095,z,r*2.38,.17,r*2.38,'wood');
  caps.push([x,z]);
 }
 group(-.40,0,-.40,0,()=>{
  box(0,floor-.20,0,bw+.56,.28,bd+.48,'hallFoundation');box(0,floor-.035,0,bw+.44,.10,bd+.40,'wood');
  for(let i=0;i<22;i++)box(-1.94+i*.185,floor+.026,0,.174,.025,bd+.27,'wood');
  for(const z of[-front,front])for(const x of xs){box(x,(floor-.08)/2,z,.42,floor-.08,.42,'hallFoundation');shaft(x,z,.295);}
  for(const side of[-1,1])for(const z of sideZ){box(side*bw/2,(floor-.08)/2,z,.40,floor-.08,.40,'hallFoundation');shaft(side*bw/2,z,.273);}
  // Two full front bays replace four narrow picket-like bays. Their screens
  // are recessed behind the broad shafts and their upper plaster is framed.
  for(const sign of[-1,1])group(0,0,sign*front,sign<0?Math.PI:0,()=>{
   for(const x of[-.875,.875]){
    box(x,floor+.34,-.46,1.43,.48,.22,'wood');lattice(x,floor+1.84,-.42,1.37,2.65);
    for(const xx of[x-.73,x+.73])box(xx,floor+1.91,-.30,.105,3.25,.25,'red');
    box(x,8.77,-.43,1.46,.48,.20,'wall');
   }
   box(0,beamY,-.01,bw+.36,.39,.47,'red');box(0,cap-.05,-.02,bw+.40,.31,.53,'redlight');
   box(0,beamY-.27,-.15,bw+.37,.12,.31,'wood');
   if(sign>0)peony.panel({emit,x:.875,y:beamY+.015,z:.245,width:1.43,height:.30,copies:2,label:'near-front-bay'});
  });
  const cuts=[-3.20,-1.60,0,1.60,3.20];
  for(const side of[-1,1])group(side*bw/2,0,0,side*Math.PI/2,()=>{
   for(let j=0;j<4;j++){
    const x=(cuts[j]+cuts[j+1])/2;
    box(x,floor+.33,-.43,1.39,.46,.20,'wood');lattice(x,floor+1.84,-.42,1.29,2.65);
    box(x,8.77,-.43,1.43,.48,.20,'wall');
    for(const xx of[x-.71,x+.71])box(xx,floor+1.91,-.30,.10,3.25,.24,'red');
   }
   box(0,beamY,0,bd+.32,.39,.47,'red');box(0,cap-.05,-.015,bd+.35,.31,.53,'redlight');
   box(0,beamY-.27,-.13,bd+.30,.12,.31,'wood');
   if(side>0)peony.panel({emit,x:-2.40,y:beamY+.015,z:.245,width:1.42,height:.30,copies:2,label:'near-return-bay'});
  });
  // Solid inner return, recessed one metre, and coffered transverse joists
  // make a real sheltered porch rather than a row of windows on the posts.
  for(let bay=0;bay<4;bay++){
   const z=-2.4+bay*1.6;box(.72,floor+1.62,z,.18,2.95,1.43,'dark');
   group(.84,0,z,Math.PI/2,()=>lattice(0,floor+1.86,0,1.28,2.62));
   box(.35,8.57,z,2.55,.19,.24,'wood');
   for(let j=0;j<5;j++)box(.35,8.68,z-.57+j*.28,2.55,.065,.17,'wood');
  }
  for(const [x,z]of caps){
   for(const part of galleryJoinery.parts)emit(part.geometry,part.material,x,cap-.03,z,1.0,.94,1.0);
   box(x,eave-.27,z,.83,.20,.83,'wood');
  }
  // Three closely seated ring tiers and substantial curved projecting ties
  // receive the same roof deck. Wider timbers replace the old exposed ladder.
  for(let tier=0;tier<3;tier++){
   const yy=cap+.17+tier*.22,out=.22+tier*.38;
   for(const side of[-1,1]){box(0,yy,side*(front+out),bw+.42+out*2,.19,.31,'red');box(side*(bw/2+out),yy,0,.31,.19,bd+.42+out*2,'red');}
  }
  for(const z of[-front,front])for(const x of xs){const sign=Math.sign(z);emit(createContinuousTimber([[x,cap+.12,z],[x,cap+.39,z+sign*.35],[x,eave-.31,z+sign*.77],[x,eave-.18,z+sign*1.04]],.23,.29,.016),'redlight');}
  for(const side of[-1,1])for(const z of[-1.6,0,1.6]){const x=side*bw/2;emit(createContinuousTimber([[x,cap+.12,z],[x+side*.35,cap+.39,z],[x+side*.77,eave-.31,z],[x+side*1.05,eave-.18,z]],.23,.29,.016),'redlight');}
  for(const x of[-1.45,1.45])lantern(x,8.12,front+.33,.38);
 });
 return{revision:'scene08-whole-bearing171-r01',frontAxes:xs,sideAxes:sideZ,shaftRadiusMetres:[.295,.273],shaftSeat:cap-.14,deepWindowSetback:.42,innerReturnSetback:1.03,compactCorniceHeight:eave-cap,peonyMounts:2,visualAccepted:false};
}
