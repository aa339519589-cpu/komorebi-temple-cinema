import * as T from 'three';
import {createContinuousTimber} from './gallery-joinery.js';
// Complete broad-shaft frame. Bearing endpoints are queried from the same
// authored roof triangles, so the curved cantilevers meet its real underside.
export function buildGrandBearing171({emit,box,between,group,lantern,lattice,galleryJoinery,grandFrame,peony,roof171}){
 const floor=grandFrame.floor,cap=grandFrame.lintel,bw=3.50,bd=6.40,front=bd/2,xs=[-1.75,0,1.75],sideZ=[-1.60,0,1.60],caps=[],contacts=[];
 const weather=(x,z)=>roof171.surfaceY(x-.40,z-.40);
 function reachAt(side,z){let reach=side>0?2.40:1.90;while(reach>.65&&weather(side*(bw/2+reach),z)===null)reach-=.15;return reach;}
 function seatAt(x,z){const side=Math.sign(x)||1,reach=reachAt(side,z),outer=weather(side*(bw/2+reach),z),near=weather(x,z+Math.sign(z||1)*1.20);return Math.min(cap,(outer??(cap+1.10))-.94,(near??(cap+1.10))-.94);}
 function shaft(x,z,r){
  const seat=seatAt(x,z),bottom=floor+.22,top=seat-.14,h=top-bottom,profile=[[0,0],[r*.98,0],[r,.10*h],[r*1.035,.38*h],[r*1.02,.62*h],[r*.96,.90*h],[r*.94,h],[0,h]],g=new T.LatheGeometry(profile.map(p=>new T.Vector2(...p)),40),p=g.attributes.position,uv=g.attributes.uv;
  for(let i=0;i<p.count;i++)uv.setXY(i,p.getY(i)/1.6,Math.atan2(p.getZ(i),p.getX(i))*r/.55);g.userData.member='171-entasis-turned-timber-shaft';
  emit(g,'red',x,bottom,z);emit(new T.CylinderGeometry(r*1.36,r*1.48,.20,32),'hallFoundation',x,floor+.10,z);box(x,seat-.095,z,r*2.38,.17,r*2.38,'wood');caps.push([x,z,seat]);
 }
 function cloudArm(length,rise,depth=.34){
  const s=new T.Shape(),L=length,R=rise;
  s.moveTo(-.22,.13);s.lineTo(.08,.13);s.lineTo(L*.35,R*.35+.13);s.lineTo(L*.73,R*.73+.13);s.lineTo(L,R+.13);
  s.bezierCurveTo(L+.055,R+.02,L-.05,R-.17,L-.18,R-.155);
  s.bezierCurveTo(L-.34,R-.11,L*.66,R*.66-.33,L*.50,R*.50-.27);
  s.quadraticCurveTo(L*.22,R*.22-.10,.055,-.205);s.lineTo(-.22,-.13);s.closePath();
  const g=new T.ExtrudeGeometry(s,{depth,bevelEnabled:true,bevelSize:.013,bevelThickness:.010,bevelSegments:3,curveSegments:20});g.translate(0,0,-depth/2);g.userData.member='171-closed-deep-carved-cantilever';return g;
 }
 function armAt(x,z,seat,dx,dz,reach){
  const endX=x+dx*reach,endZ=z+dz*reach,target=(weather(endX,endZ)??(seat+1.08))-.25,yaw=Math.atan2(-dz,dx);
  for(let level=0;level<3;level++){
   const start=level*.25*reach,end=(.59+level*.205)*reach,y=seat+.12+level*.19,finish=target-.19*(2-level),length=end-start;
   emit(cloudArm(length,Math.max(.05,finish-y),.38-level*.035),'redlight',x+dx*start,y,z+dz*start,1,1,1,[0,yaw,0]);
   if(level){const q=start+.09;box(x+dx*q,y-.055,z+dz*q,.32,.17,.42,'wood');}
  }
  box(endX,target+.045,endZ,.31,.19,.40,'wood');contacts.push({shaft:[x,seat,z],roofReceiver:[endX,target+.14,endZ],actualWeatherY:weather(endX,endZ)});return[endX,target-.02,endZ];
 }
 group(-.40,0,-.40,0,()=>{
  box(0,floor-.20,0,bw+.56,.28,bd+.48,'hallFoundation');box(0,floor-.035,0,bw+.44,.10,bd+.40,'wood');
  for(let i=0;i<22;i++)box(-1.94+i*.185,floor+.026,0,.174,.025,bd+.27,'wood');
  for(const z of[-front,front])for(const x of xs){box(x,(floor-.08)/2,z,.42,floor-.08,.42,'hallFoundation');shaft(x,z,.295);}
  for(const side of[-1,1])for(const z of sideZ){box(side*bw/2,(floor-.08)/2,z,.40,floor-.08,.40,'hallFoundation');shaft(side*bw/2,z,.273);}
  for(const sign of[-1,1])group(0,0,sign*front,sign<0?Math.PI:0,()=>{
   const seat=Math.min(...xs.map(x=>seatAt(x,sign*front))),beamY=seat-1.05,windowTop=beamY-.60,windowBottom=floor+.50;
   for(const x of[-.875,.875]){
    box(x,floor+.34,-.46,1.43,.48,.22,'wood');lattice(x,(windowBottom+windowTop)/2,-.42,1.37,windowTop-windowBottom);
    for(const xx of[x-.73,x+.73])box(xx,(floor+.28+windowTop)/2,-.30,.105,windowTop-floor+.38,.25,'red');
    box(x,seat-.49,-.43,1.46,.48,.20,'wall');
   }
   box(0,beamY,-.01,bw+.36,.39,.47,'red');box(0,seat-.05,-.02,bw+.40,.31,.53,'redlight');box(0,beamY-.27,-.15,bw+.37,.12,.31,'wood');
   if(sign>0)peony.panel({emit,x:.875,y:beamY+.015,z:.245,width:1.43,height:.30,copies:2,label:'near-front-bay'});
  });
  const cuts=[-3.20,-1.60,0,1.60,3.20];
  for(const side of[-1,1])group(side*bw/2,0,0,side*Math.PI/2,()=>{
   for(let j=0;j<4;j++){
    const x=(cuts[j]+cuts[j+1])/2,zz=-side*x,seat=seatAt(side*bw/2,zz),beamY=seat-1.05,windowTop=beamY-.60,windowBottom=floor+.50;
    box(x,floor+.33,-.43,1.39,.46,.20,'wood');lattice(x,(windowBottom+windowTop)/2,-.42,1.29,Math.max(.9,windowTop-windowBottom));box(x,seat-.49,-.43,1.43,.48,.20,'wall');
    for(const xx of[x-.71,x+.71])box(xx,(floor+.28+windowTop)/2,-.30,.10,windowTop-floor+.38,.24,'red');
    box(x,beamY,0,1.64,.39,.47,'red');box(x,seat-.05,-.015,1.64,.31,.53,'redlight');box(x,beamY-.27,-.13,1.64,.12,.31,'wood');
   }
   if(side>0){const seat=seatAt(bw/2,2.40);peony.panel({emit,x:-2.40,y:seat-1.035,z:.245,width:1.42,height:.30,copies:2,label:'near-return-bay'});}
  });
  for(let bay=0;bay<4;bay++){
   const z=-2.4+bay*1.6,seat=seatAt(bw/2,z),h=Math.max(2.0,seat-floor-1.3);box(.72,floor+h/2+.18,z,.18,h,1.43,'dark');group(.84,0,z,Math.PI/2,()=>lattice(0,floor+h/2+.23,0,1.28,h-.18));
   box(.35,seat-.68,z,2.55,.19,.24,'wood');for(let j=0;j<5;j++)box(.35,seat-.57,z-.57+j*.28,2.55,.065,.17,'wood');
  }
  for(const [x,z,seat]of caps)for(const part of galleryJoinery.parts)emit(part.geometry,part.material,x,seat-.03,z,.88,.78,.88);
  // Inner ring members are hidden behind the carved crossed arms, while
  // each outer carrier is seated directly below the queried roof surface.
  for(const sign of[-1,1]){
   const z=sign*front,pts=xs.map(x=>[x,seatAt(x,z)+.15,z]);emit(createContinuousTimber(pts,.29,.32,.012),'red');
   const ends=[];for(const x of xs){const seat=seatAt(x,z),reach=1.20;ends.push(armAt(x,z,seat,0,sign,reach));}
   emit(createContinuousTimber(ends,.25,.32,.014),'wood');
  }
  for(const side of[-1,1]){
   const ends=[],zs=[-front,...sideZ,front];
   for(const z of zs){const x=side*bw/2,seat=seatAt(x,z);ends.push(armAt(x,z,seat,side,0,reachAt(side,z)));}
   emit(createContinuousTimber(zs.map(z=>[side*bw/2,seatAt(side*bw/2,z)+.15,z]),.29,.32,.012),'red');
   emit(createContinuousTimber(ends,.25,.32,.014),'wood');
  }
  for(const x of[-1.45,1.45])lantern(x,seatAt(x,front)-1.13,front+.33,.38);
 });
 return{revision:'scene08-coupled-roof-bearing171-r02',frontAxes:xs,sideAxes:sideZ,shaftRadiusMetres:[.295,.273],deepWindowSetback:.42,innerReturnSetback:1.03,roofCoupling:'Actual same-scene roof-triangle XZ barycentric query, no image depth',bearingHeights:caps.map(([x,z,seat])=>({axis:[x,z],seat})),roofReceivers:contacts,peonyMounts:2,visualAccepted:false};
}
