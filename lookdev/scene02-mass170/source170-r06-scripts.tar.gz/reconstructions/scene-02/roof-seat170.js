import {T} from './kernel.js';

// Broad turned-metal boot seats on a closed ceramic saddle whose underside
// follows the true top-roof surface. The outside lip no longer hangs above it.
export function createSorinRoofSeat170({eave,rise,halfWidth,curl}){
 const pos=[],uv=[],ix=[],N=8,R=.72,top=eave+rise+.025;
 const roofY=(x,z)=>{const a=Math.abs(x),b=Math.abs(z),t=Math.max(a,b)/halfWidth,u=Math.min(a,b)/Math.max(a,b,1e-8);return eave+rise*Math.pow(1-t,1.46)+curl*Math.pow(t,7)*(.18+.82*Math.pow(u,8));};
 for(const lower of[false,true])for(let k=0;k<N;k++){
  const a=k*Math.PI/4,x=Math.cos(a)*R,z=Math.sin(a)*R;pos.push(x,lower?roofY(x,z)+.010:top,z);uv.push(x,z);
 }
 const tc=pos.length/3;pos.push(0,top,0);uv.push(0,0);const bc=pos.length/3;pos.push(0,eave+rise-.020,0);uv.push(0,0);
 for(let k=0;k<N;k++){const n=(k+1)%N;ix.push(tc,n,k,bc,k+N,n+N,k,n,k+N,n,n+N,k+N);}
 const g=new T.BufferGeometry();g.name='scene02-170-closed-roof-fitted-octagonal-sorin-saddle';g.setAttribute('position',new T.Float32BufferAttribute(pos,3));g.setAttribute('uv',new T.Float32BufferAttribute(uv,2));g.setIndex(ix);g.computeVertexNormals();g.userData.closedRoofFittedSeat=true;return g;
}
