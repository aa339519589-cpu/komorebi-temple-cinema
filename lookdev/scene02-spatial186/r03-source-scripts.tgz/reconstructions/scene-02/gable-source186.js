import {T} from './kernel.js';
import {layout} from './layout117.js';
import {GLTFLoader} from 'three/addons/loaders/GLTFLoader.js';
// One exact verified176 sculpture mounted on the new closed carrying body.
// Matrix compensation cancels the old nonuniform hall transform, preserving
// the actual donor's world-space aspect, relief depth and source normals.
export async function loadCarvedGable186(mats){
 const loaded=await new GLTFLoader().loadAsync(new URL('./assets/carved-gable186/cloud-scroll.glb',import.meta.url).href);let geometry;loaded.scene.traverse(o=>{if(o.isMesh){if(geometry)throw Error('Expected one source176 primitive');geometry=o.geometry;}});if(!geometry)throw Error('Source176 primitive absent');
 mats.actualCloudGilt186=new T.MeshStandardMaterial({name:'scene02-186-actual-cloud-gable-gilt',color:0xb99a5c,roughness:.50,metalness:.82,envMapIntensity:.82});
 return{mount(b,base,plane){
  const [sx,sy,sz]=layout.hall.scale,uniform=.92,p=[0,base+.045,plane+.48],fit=[uniform/sx,uniform/sy,uniform/sz];
  b.put(geometry,'actualCloudGilt186',p,fit);
  // Original five measured planar cut loops terminate inside two closed
  // timber cheek returns. The donor is not presented as a closed bracket.
  for(const side of[-1,1])b.box(side*(uniform*.5+.012)/sx,p[1]+uniform*.435/sy,p[2]+uniform*.135/sz,.10/sx,uniform*.95/sy,uniform*.30/sz,'hallBearing');
  return{source:'Wood Carving of Dragon by SCANOLOGY_3D / 3dscantech, CC BY4.0',url:'https://sketchfab.com/3d-models/wood-carving-of-dragon-1336fa1889cf4eba829594fa30edd6ff',sha256:'0c693ba1108d00c08a8b76113998cfd498fef6cdd09ff4767d92b3a42825feee',actualSourceInstances:1,triangles:geometry.index.count/3,sourceBuffersUnchanged:true,worldUniformWidthFitMetres:uniform,localMatrixCompensation:fit,worldLinearFit:'Held hall rotation times uniform.92; nonuniform hall scale is exactly canceled for donor geometry',positionInGableCoordinates:p,mount:'Closed pierced timber carrier and two solid cut-loop cheek returns',culture:'Unspecified by creator, not identified as a Japanese reference artifact',visualAccepted:false};
 }};
}
