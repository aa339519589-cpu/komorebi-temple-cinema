import * as T from 'three';
import{HALL_ENVELOPE143}from'./hall-envelope143.js';
import{PAGODA_FRAME143}from'./pagoda-frame143.js';
export const NIGHT203_REVISION='scene09-bounded-practical-cobalt-night203-r01';
const transformed=(pose,p)=>new T.Vector3(...p).applyMatrix4(new T.Matrix4().compose(new T.Vector3(...pose.position),new T.Quaternion().setFromAxisAngle(new T.Vector3(0,1,0),pose.yaw),new T.Vector3(...pose.scale)));

export function configurePracticals203({scene,fixtures,moon,fill,warmKey,materials,M}){
 // Existing fixture positions and physical assemblies are untouched. Small
 // secondary lamps have local smooth cutoffs; primary pools receive actual
 // geometry shadows within the native sampler budget.
 scene.remove(fill);for(const o of[...scene.children])if(o.isHemisphereLight||o.isRectAreaLight)scene.remove(o);
 moon.intensity=.90;moon.shadow.radius=3.2;moon.name='scene09-203-cool-night-key';
 for(const o of[...scene.children])if(o.isPointLight&&!fixtures.includes(o)){
  if(o.distance>3.9||!o.distance)scene.remove(o);else{o.intensity*=.7;o.castShadow=false;}
 }
 for(const o of[...scene.children])if(o.isSpotLight&&o!==warmKey&&!o.name.includes('finial')){scene.remove(o);if(o.target)scene.remove(o.target);}
 const records=[],chosen=new Set();
 function closest(p,label,filter=()=>true){const q=fixtures.filter(l=>!chosen.has(l)&&filter(l)).sort((a,b)=>a.position.distanceToSquared(p)-b.position.distanceToSquared(p))[0];if(q){chosen.add(q);q.userData.pool203=label;}}
 closest(new T.Vector3(1,7.2,23.7),'near-west-modeled-lantern');closest(new T.Vector3(7.7,7.3,21.6),'near-east-modeled-lantern');
 const stone=fixtures.find(l=>l.userData.stoneHero158);if(stone){chosen.add(stone);stone.userData.pool203='hero158-stone-chamber';}
 for(const x of[-4.8,4.8])closest(transformed(HALL_ENVELOPE143,[x,6.1,5.4]),'main-hall-portal-'+x,l=>l.position.z<0&&l.position.y>4);
 closest(transformed(PAGODA_FRAME143,[0,5.4,3.7]),'pagoda-occupied-gallery',l=>l.position.x< -5);
 for(const l of fixtures){const source=l.userData.source203||{},near=l.position.z>15,primary=chosen.has(l),hero=!!l.userData.stoneHero158;
  const requested=source.worldReach||5,reach=primary?(near?15:hero?9:10):near?8:Math.min(4.8,Math.max(2.0,requested));l.distance=reach;l.decay=2;
  if(!primary&&!near)l.intensity*=.55;
  l.castShadow=primary;if(primary){l.shadow.mapSize.set(hero?768:512,hero?768:512);l.shadow.camera.near=hero?.06:.10;l.shadow.camera.far=reach;l.shadow.bias=-.000025;l.shadow.normalBias=hero?.008:.012;l.shadow.radius=4.0;}
  records.push({position:l.position.toArray(),intensity:l.intensity,reach,decay:l.decay,geometryShadow:l.castShadow,role:l.userData.pool203||'secondary-modeled-local-lantern',originalRequested:source});
 }
 // Preserve every original paper texture, but keep room transoms below the
 // visible lantern chambers in radiance. No architectural skin emits light.
 M.windowPaper.emissiveIntensity=.42;M.pagodaPaper.emissiveIntensity=.44;M.stonePaper.emissiveIntensity=.90;
 for(const m of materials)if(m.emissive&&m!==M.glow&&m.emissiveMap!==M.paper.emissiveMap&&!/paper|washi/i.test(m.name))m.emissiveIntensity=0;
 M.glow.emissiveIntensity=.65;
 return{revision:NIGHT203_REVISION,practicals:records,removedFacadeAreaWash:true,removedWarmDirectionalFill:true,removedUnmodeledGardenGrazes:true,paper:{lantern:M.paper.emissiveIntensity,room:M.windowPaper.emissiveIntensity,pagoda:M.pagodaPaper.emissiveIntensity,stone:M.stonePaper.emissiveIntensity},shadowScope:'Dominant modeled practicals and retained cool/shrine/finial sources; secondary fixtures use bounded smooth local falloff',exactAreaEmitterOrPathTracedGI:false,referenceImageSampled:false,visualAccepted:false};
}

// Sky and courtyard are genuinely captured native radiance. Ceramic receives
// the cobalt exterior field; metal/wood retain a restrained court reflection.
export function captureNight203({renderer,scene,sky,water,wetVeranda,materials}){
 const pmrem=new T.PMREMGenerator(renderer),skyScene=new T.Scene(),skyCopy=new T.Mesh(sky.geometry,sky.material);skyScene.add(skyCopy);let skyEnvironment,courtEnvironment;const targets=[];
 function capture(world,position){const target=new T.WebGLCubeRenderTarget(128,{type:T.HalfFloatType,generateMipmaps:false}),probe=new T.CubeCamera(.18,220,target);probe.position.fromArray(position);world.add(probe);try{world.updateMatrixWorld(true);renderer.shadowMap.needsUpdate=true;probe.update(renderer,world);return pmrem.fromCubemap(target.texture);}finally{probe.removeFromParent();target.dispose();}}
 const w=water.visible,v=wetVeranda.visible;water.visible=wetVeranda.visible=false;
 try{skyEnvironment=capture(skyScene,[0,0,0]);scene.environment=skyEnvironment.texture;scene.environmentIntensity=.70;courtEnvironment=capture(scene,[1.5,4.1,4]);
  for(const m of materials)if(m.metalness>.30||m.userData.metricTimberGrain){m.envMap=courtEnvironment.texture;m.envMapRotation.set(0,0,0);m.envMapIntensity=m.metalness>.30?.75:.32;m.needsUpdate=true;targets.push(m.name);}
 }finally{water.visible=w;wetVeranda.visible=v;pmrem.dispose();renderer.shadowMap.needsUpdate=true;}
 return{info:{position:[1.5,4.1,4],resolution:128,actualSkyAndCourtCaptures:true,ceramicUsesExteriorCobalt:true,restrainedCourtMaterials:targets,photoSampled:false,visualAccepted:false},dispose(){skyEnvironment.dispose();courtEnvironment.dispose();}};
}
