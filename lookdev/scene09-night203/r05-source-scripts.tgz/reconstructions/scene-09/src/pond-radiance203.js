// A genuine planar scene capture with small nonparallel gravity-wave slopes.
// No regular luminance stripes, warm-pixel gain or painted reflection streaks.
export const pondFragment203=`uniform sampler2D tDiffuse;uniform vec3 color;uniform float time;varying vec4 vUv;varying vec3 vWorld;
float hash203(vec2 p){return fract(sin(dot(p,vec2(127.1,311.7)))*43758.5453);}float noise203(vec2 p){vec2 i=floor(p),f=fract(p);f=f*f*(3.-2.*f);return mix(mix(hash203(i),hash203(i+vec2(1,0)),f.x),mix(hash203(i+vec2(0,1)),hash203(i+vec2(1,1)),f.x),f.y);}
float height203(vec2 p){float packet=.55+.65*noise203(p*.45),phase=2.*noise203(p*.31+vec2(7,3));return .006*sin(dot(p,vec2(.53,.81))+time*.27)+.002*sin(dot(p,vec2(-1.11,.37))-time*.19)+.0004*sin(dot(p,vec2(1.97,2.63))+time*.42)+packet*(.00035*sin(dot(p,vec2(9.7,11.3))+phase+time*.8)+.00017*sin(dot(p,vec2(-18.1,5.3))-phase-time*1.1)+.00008*sin(dot(p,vec2(3.9,27.3))+phase*.73+time*.9));}
void main(){vec2 uv=vUv.xy/vUv.w,p=vWorld.xz;float eps=.012;vec2 gradient=vec2(height203(p+vec2(eps,0))-height203(p-vec2(eps,0)),height203(p+vec2(0,eps))-height203(p-vec2(0,eps)))/(2.*eps);vec2 slope=gradient*.22;uv+=slope;
vec3 r=texture2D(tDiffuse,uv).rgb*.56;r+=texture2D(tDiffuse,uv+slope*.18+vec2(.00020,-.00012)).rgb*.22;r+=texture2D(tDiffuse,uv-slope*.18-vec2(.00020,-.00012)).rgb*.22;
vec3 waveNormal=normalize(vec3(-gradient.x,1.,-gradient.y));float nDotV=clamp(abs(dot(normalize(cameraPosition-vWorld),waveNormal)),0.,1.);float fresnel=.02037+.97963*pow(1.-nDotV,5.);vec3 water=color*(1.-fresnel)*.35+r*fresnel;gl_FragColor=vec4(water,1.);
#include <tonemapping_fragment>
#include <colorspace_fragment>
}`;

export const wetVerandaFragment203=`uniform sampler2D tDiffuse;uniform sampler2D roughMap;uniform vec3 color;varying vec4 rUv;varying vec2 pUv;varying vec3 wPos;
void main(){vec2 u=rUv.xy/rUv.w;float rough=texture2D(roughMap,pUv*.42).g;vec2 offset=vec2(sin(wPos.x*3.7+wPos.z*1.1),cos(wPos.z*4.3-wPos.x*2.1))*.00028;vec3 r=texture2D(tDiffuse,u+offset).rgb*.60;r+=texture2D(tDiffuse,u-offset+vec2(.00022,.00014)).rgb*.20;r+=texture2D(tDiffuse,u-offset-vec2(.00022,.00014)).rgb*.20;
float wet=clamp(.25+.85*(1.-rough),.22,.98);float cosView=clamp(abs(normalize(cameraPosition-wPos).y),0.,1.);float fresnel=.02037+.97963*pow(1.-cosView,5.);gl_FragColor=vec4(r,clamp(fresnel*wet,.020,.90));
#include <tonemapping_fragment>
#include <colorspace_fragment>
}`;
