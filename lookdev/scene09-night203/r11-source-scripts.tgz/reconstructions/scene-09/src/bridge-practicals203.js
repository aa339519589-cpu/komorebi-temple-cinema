import * as T from 'three';

// The reference has small luminous cases at the bridge landings. The old
// bridge retained only finials there. Two closed cases now sit on four-legged
// bronze saddles around those unchanged finials, carried by the actual caps.
export function buildBridgePracticals203(api){
 const{emit,box,group,light,materials:M}=api;
 const ring=new T.Shape([new T.Vector2(-.17,-.17),new T.Vector2(.17,-.17),new T.Vector2(.17,.17),new T.Vector2(-.17,.17)]),hole=new T.Path([new T.Vector2(-.104,-.104),new T.Vector2(-.104,.104),new T.Vector2(.104,.104),new T.Vector2(.104,-.104)]);ring.holes.push(hole);
 const saddle=new T.ExtrudeGeometry(ring,{depth:.035,bevelEnabled:true,bevelSize:.004,bevelThickness:.003,bevelSegments:1,steps:1});saddle.rotateX(-Math.PI/2);
 const cap=new T.CylinderGeometry(.105,.32,.14,4,1,false),crown=new T.LatheGeometry([[0,0],[.046,0],[.058,.025],[.043,.055],[.059,.085],[.039,.13],[0,.19]].map(p=>new T.Vector2(...p)),20),records=[];
 group(-.6,0,0,0,()=>{
  for(const[x,cd]of[[-8,23],[8,20]]){
   const deck=1.25,z=3.03;
   group(x,deck,z,0,()=>{
    emit(saddle,M.lanternMetal,0,1.18,0);
    for(const a of[-1,1])for(const b of[-1,1])box(a*.146,1.38,b*.146,.024,.41,.024,M.lanternMetal);
    box(0,1.59,0,.39,.045,.39,M.lanternMetal);box(0,1.62,0,.35,.018,.35,M.lanternEdge);
    for(let face=0;face<4;face++)group(0,0,0,face*Math.PI/2,()=>{
     box(0,1.845,.163,.326,.414,.008,M.paper);
     for(const xx of[-.174,.174])box(xx,1.845,.179,.025,.47,.029,M.lanternMetal);
     for(const yy of[1.625,2.065])box(0,yy,.182,.373,.024,.030,M.lanternEdge);
     for(const xx of[-.081,0,.081])box(xx,1.845,.183,.010,.408,.013,M.lanternMetal);
     for(const yy of[1.755,1.935])box(0,yy,.184,.325,.010,.013,M.lanternMetal);
    });
    box(0,2.096,0,.42,.04,.42,M.lanternMetal);emit(cap,M.lanternMetal,0,2.18,0,1,1,1,Math.PI/4);emit(crown,M.lanternEdge,0,2.25,0);
    light(0,1.845,0,cd,4.5,{kind:'bridge-post203'});
   });
   records.push({originalPost:[x,deck,z],worldPost:[-.6+x*.72,deck,z],chamberLocalHeight:deck+1.845,candela:cd,reach:4.5,physicalMount:'Closed bronze saddle encircles original finial; four closed supports land on original bridge post cap',inferredReferencePlacement:true});
  }
 },[.72,1,1]);
 return{revision:'scene09-solid-bridge-post-practicals203-r11',fixtures:records,closedSolidPartsPerFixture:50,legacyBridgeGeometryHeld:true,referencePixelsSampled:false,visualAccepted:false};
}
