import * as T from 'three';
import{HALL_ENVELOPE143}from'./hall-envelope143.js';
import{PAGODA_FRAME143}from'./pagoda-frame143.js';
export const NIGHT203_REVISION='scene09-bounded-practical-cobalt-night203-r06';
const transformed=(pose,p)=>new T.Vector3(...p).applyMatrix4(new T.Matrix4().compose(new T.Vector3(...pose.position),new T.Quaternion().setFromAxisAngle(new T.Vector3(0,1,0),pose.yaw),new T.Vector3(...pose.scale)));
const hardwareResources203=new WeakMap();
export function disposePracticalHardware203(scene){const r=hardwareResources203.get(scene);if(!r)return;for(const o of r.objects)o.removeFromParent();for(const g of r.geometry)g.dispose();for(const m of r.materials)m.dispose();hardwareResources203.delete(scene);}

function addDownlights203(scene){
 const body=new T.CylinderGeometry(.13,.15,.10,24),stem=new T.CylinderGeometry(.016,.016,.30,12),opal=new T.CylinderGeometry(.104,.104,.012,24),metal=new T.MeshStandardMaterial({name:'scene09-203-hooded-downlight-bronze',color:0x241d14,roughness:.64,metalness:.78}),emitter=new T.MeshBasicMaterial({name:'scene09-203-opal-aperture-exitance',color:new T.Color().setRGB(1.45,.82,.31)}),objects=[],records=[];
 function fixture(pose,label,local,target,cd,reach,angle,mountLocal=null,shadow=true){
  const p=transformed(pose,local),q=transformed(pose,target),direction=q.clone().sub(p).normalize(),g=new T.Group();g.name=label;g.position.copy(p);g.quaternion.setFromUnitVectors(new T.Vector3(0,-1,0),direction);
  const hood=new T.Mesh(body,metal);hood.castShadow=true;hood.receiveShadow=true;hood.position.y=.035;const disk=new T.Mesh(opal,emitter);disk.position.y=-.021;g.add(hood,disk);scene.add(g);objects.push(g);
  const rod=new T.Mesh(stem,metal),head=p.clone().addScaledVector(direction,-.07),anchor=mountLocal?transformed(pose,mountLocal):p.clone().add(new T.Vector3(0,.31,0)),delta=anchor.clone().sub(head);rod.castShadow=true;rod.receiveShadow=true;rod.position.copy(anchor).add(head).multiplyScalar(.5);rod.scale.y=delta.length()/.30;rod.quaternion.setFromUnitVectors(new T.Vector3(0,1,0),delta.normalize());scene.add(rod);objects.push(rod);
  const light=new T.SpotLight(0xffffff,cd,reach,angle,.72,2);light.color.setRGB(1,.62,.28);light.name=label+'-finite-cone';light.position.copy(p).addScaledVector(direction,.055);light.target.position.copy(q);light.castShadow=shadow;light.shadow.mapSize.set(768,768);light.shadow.camera.near=.08;light.shadow.camera.far=reach;light.shadow.bias=-.000035;light.shadow.normalBias=.012;light.shadow.radius=4;scene.add(light,light.target);objects.push(light,light.target);
  records.push({label,position:p.toArray(),target:q.toArray(),mountAnchor:anchor.toArray(),candela:cd,reach,coneAngle:angle,geometryShadow:shadow,mount:'Closed bronze arm from actual181 joist/post/beam anchor to hood body and closed opal aperture',inferredPhotographicPlacement:true});
 }
 fixture(HALL_ENVELOPE143,'scene09-203-west-entry-hooded-practical',[-5.5,7.30,4.50],[-4.7,4.8,1.55],180,9,.70,[-4.8,7.465,4.50]);
 fixture(HALL_ENVELOPE143,'scene09-203-east-entry-hooded-practical',[5.3,7.30,4.45],[4.6,4.9,1.65],145,8.5,.67,[4.8,7.465,4.45]);
 fixture(HALL_ENVELOPE143,'scene09-203-west-upper-post-practical',[-5.07,9.55,5.38],[-4.10,9.15,3.45],105,5.6,.72,[-5.40,9.72,5.20]);
 fixture(HALL_ENVELOPE143,'scene09-203-east-upper-post-practical',[5.07,9.55,5.38],[4.25,9.08,3.45],85,5.4,.70,[5.40,9.72,5.20]);
 for(const[k,cd]of[[0,140],[2,110],[4,85]]){const floor=PAGODA_FRAME143.floor+k*PAGODA_FRAME143.pitch,half=[4.92,4.52,4.12,3.75,3.40][k]/2;fixture(PAGODA_FRAME143,'scene09-203-tier-'+(k+1)+'-gallery-practical',[0,floor+1.42,half+.24],[0,floor+.82,half-.48],cd,k===0?5.4:2.6,.76,[0,floor+1.56,half+.24],k===0);}
 hardwareResources203.set(scene,{objects,geometry:[body,stem,opal],materials:[metal,emitter]});return records;
}

export function withNightVolume203(M,materials,label,fn){const held={};for(const k of['red','wood','dark','eaveDark','carvedTimber','ivory','gold','bronze','darkGilt','sanctuaryGilt']){const old=M[k];if(!old)continue;held[k]=old;const m=old.clone();m.name='scene09-203-'+label+'-'+k;m.onBeforeCompile=old.onBeforeCompile;m.customProgramCacheKey=old.customProgramCacheKey;m.userData={...old.userData,nightVolume203:label};materials.push(m);M[k]=m;}try{return fn();}finally{Object.assign(M,held);}}

export function calibrateWetGranite203(materials,ownedTextures){
 const source=materials[0].map,canvas=document.createElement('canvas');canvas.width=canvas.height=512;const context=canvas.getContext('2d',{willReadFrequently:true});context.drawImage(source.image,0,0,512,512);const input=context.getImageData(0,0,512,512),linear=v=>(v/=255)<=.04045?v/12.92:((v+.055)/1.055)**2.4,srgb=v=>v<=.0031308?v*12.92:1.055*v**(1/2.4)-.055,luminance=new Float32Array(512*512);let mean=0;
 for(let i=0;i<luminance.length;i++){const j=i*4,l=.2126*linear(input.data[j])+.7152*linear(input.data[j+1])+.0722*linear(input.data[j+2]);luminance[i]=l;mean+=l/luminance.length;}
 const targets=[[.032,.036,.040],[.027,.031,.034],[.043,.047,.050],[.033,.037,.040]],records=[];
 materials.forEach((m,k)=>{const c=document.createElement('canvas');c.width=c.height=512;const ctx=c.getContext('2d'),data=ctx.createImageData(512,512),target=targets[k],oldColor=m.color.toArray();for(let i=0;i<luminance.length;i++){const grain=T.MathUtils.clamp((luminance[i]/mean)**.50,.55,1.55);for(let a=0;a<3;a++)data.data[i*4+a]=Math.round(srgb(target[a]*grain)*255);data.data[i*4+3]=255;}ctx.putImageData(data,0,0);const map=new T.CanvasTexture(c);map.colorSpace=T.SRGBColorSpace;map.wrapS=source.wrapS;map.wrapT=source.wrapT;map.repeat.copy(source.repeat);map.offset.copy(source.offset);map.center.copy(source.center);map.rotation=source.rotation;map.anisotropy=source.anisotropy;ownedTextures.push(map);m.map=map;m.color.setRGB(1,1,1);m.needsUpdate=true;records.push({name:m.name,sourceMeanLinearLuminance:mean,oldMultiplyColor:oldColor,authoredWetBodyLinearRGB:target,formula:'targetRGB * clamp((sourceLinearLuminance / sourceMean)^0.5,0.55,1.55)',normalAndRoughnessMapsRetained:true});});
 return{revision:'scene09-source-grain-wet-granite203-r05',source:'Existing CC0 Granite Tile04 face albedo, independently declared in the project',records,sourcePixelsChanged:false,scenePhotographSampled:false,scope:'Only four near wet-veranda slab albedos; regular portable PBR maps, unchanged metric UV transform',authoredReflectanceNotSurveyed:true,visualAccepted:false};
}

export function configurePracticals203({scene,fixtures,moon,fill,warmKey,materials,M}){
 // Existing fixture positions and physical assemblies are untouched. Small
 // secondary lamps have local smooth cutoffs; primary pools receive actual
 // geometry shadows within the native sampler budget.
 scene.remove(fill);for(const o of[...scene.children])if(o.isHemisphereLight||o.isRectAreaLight)scene.remove(o);
 moon.intensity=1.30;moon.castShadow=false;moon.name='scene09-203-cool-night-key';warmKey.castShadow=false;
 for(const o of[...scene.children])if(o.isPointLight&&!fixtures.includes(o)){
  if(o.distance>3.9||!o.distance)scene.remove(o);else{o.intensity*=.7;o.castShadow=false;}
 }
 for(const o of[...scene.children])if(o.isSpotLight&&o!==warmKey&&!o.name.includes('finial')){scene.remove(o);if(o.target)scene.remove(o.target);}
 const records=[],chosen=new Set();
 function closest(p,label,filter=()=>true){const q=fixtures.filter(l=>!chosen.has(l)&&filter(l)).sort((a,b)=>a.position.distanceToSquared(p)-b.position.distanceToSquared(p))[0];if(q){chosen.add(q);q.userData.pool203=label;}}
 closest(new T.Vector3(1,7.2,23.7),'near-west-modeled-lantern');closest(new T.Vector3(7.7,7.3,21.6),'near-east-modeled-lantern');
 closest(new T.Vector3(4.6,7,34.4),'near-behind-modeled-lantern',l=>l.position.z>32);
 const stone=fixtures.find(l=>l.userData.stoneHero158);if(stone){chosen.add(stone);stone.userData.pool203='hero158-stone-chamber';}
 for(const x of[-4.8,4.8])closest(transformed(HALL_ENVELOPE143,[x,6.1,5.4]),'main-hall-portal-'+x,l=>l.position.z<0&&l.position.y>4);
 closest(transformed(PAGODA_FRAME143,[0,5.4,3.7]),'pagoda-occupied-gallery',l=>l.position.x< -5);
 for(const l of fixtures){const source=l.userData.source203||{},near=l.position.z>15,primary=chosen.has(l),hero=!!l.userData.stoneHero158,chamberAnchor=l.position.toArray();
  if(primary){const role=l.userData.pool203,pose=role.startsWith('main-hall')?HALL_ENVELOPE143:role.startsWith('pagoda')?PAGODA_FRAME143:null,front=pose?new T.Vector3(Math.sin(pose.yaw),0,Math.cos(pose.yaw)).multiplyScalar(-1):new T.Vector3(...(source.worldFront||[0,0,1])),size=source.assemblyScale||1,r=hero?.49*size:source.requestedIntensity>=38?.48*size:.36*Math.sqrt((source.requestedIntensity||1)/24.5)*size;l.position.addScaledVector(front,r*1.05);l.intensity*=near?1.20:hero?1.45:pose===PAGODA_FRAME143?2.8:1.65;}
  if(near&&primary){l.position.fromArray(chamberAnchor);if(l.userData.pool203==='near-behind-modeled-lantern'){l.position.addScaledVector(new T.Vector3(...(source.worldFront||[0,0,1])),-.50*(source.assemblyScale||1));l.intensity=145;}}
  l.color.setRGB(1,.62,.28);
  const requested=source.worldReach||5,reach=primary?(near?15:hero?9:10):near?8:Math.min(4.8,Math.max(2.0,requested));l.distance=reach;l.decay=2;
  if(!primary&&!near)l.intensity*=.55;
  l.castShadow=primary;if(primary){l.shadow.mapSize.set(hero?768:512,hero?768:512);l.shadow.camera.near=hero?.06:.10;l.shadow.camera.far=reach;l.shadow.bias=-.000025;l.shadow.normalBias=hero?.008:.012;l.shadow.radius=12.0;}
  if(l.userData.pool203?.startsWith('main-hall')||l.userData.pool203?.startsWith('pagoda')){l.castShadow=false;l.distance=3.8;}
  records.push({chamberAnchor,position:l.position.toArray(),intensity:l.intensity,reach:l.distance,decay:l.decay,geometryShadow:l.castShadow,role:l.userData.pool203||'secondary-modeled-local-lantern',sourceApproximation:near?'Visible near cases retain centre bulbs; the existing behind-observer fixture has a backward paper-exit proxy for the paving':primary?'Aggregate radiance exiting the modeled paper face':'Local secondary fixture',originalRequested:source});
 }
 // Preserve every original paper texture, but keep room transoms below the
 // visible lantern chambers in radiance. No architectural skin emits light.
 M.windowPaper.emissiveIntensity=.55;M.pagodaPaper.emissiveIntensity=.70;M.stonePaper.emissiveIntensity=.90;
 for(const m of materials)if(m.emissive){if(m.emissiveMap===M.paper.emissiveMap||/paper|washi/i.test(m.name)){m.emissive.setRGB(1,.53,.20);const old=m.onBeforeCompile;m.onBeforeCompile=s=>{old.call(m,s);s.fragmentShader=s.fragmentShader.replace('#include <lights_fragment_end>','#include <lights_fragment_end>\nreflectedLight.directDiffuse=vec3(0.);reflectedLight.indirectDiffuse=vec3(0.);reflectedLight.directSpecular=vec3(0.);reflectedLight.indirectSpecular=vec3(0.);');};m.customProgramCacheKey=()=> 'scene09-203-defined-paper-exitance-r03';m.needsUpdate=true;}else if(m!==M.glow)m.emissiveIntensity=0;}
 M.glow.emissiveIntensity=.65;
 const downlights=addDownlights203(scene);
 return{revision:NIGHT203_REVISION,practicals:records,downlights,removedFacadeAreaWash:true,removedWarmDirectionalFill:true,removedUnmodeledGardenGrazes:true,paper:{lantern:M.paper.emissiveIntensity,room:M.windowPaper.emissiveIntensity,pagoda:M.pagodaPaper.emissiveIntensity,stone:M.stonePaper.emissiveIntensity,definedExitanceSuppressesProxySelfIllumination:true},shadowScope:'Near lanterns, hero158, finite hooded gallery downlights and finial use geometry shadows; secondary sources have bounded local ranges',exactAreaEmitterOrPathTracedGI:false,referenceImageSampled:false,visualAccepted:false};
}

// Sky and courtyard are genuinely captured native radiance. Ceramic receives
// the cobalt exterior field; metal/wood retain a restrained court reflection.
export function captureNight203({renderer,scene,sky,water,wetVeranda,materials}){
 const pmrem=new T.PMREMGenerator(renderer),skyScene=new T.Scene(),skyCopy=new T.Mesh(sky.geometry,sky.material);skyScene.add(skyCopy);let skyEnvironment,courtEnvironment,shadowsReady=false;const targets=[],volumes=[],volumeEnvironments=[];
 function capture(world,position){const target=new T.WebGLCubeRenderTarget(128,{type:T.HalfFloatType,generateMipmaps:false}),probe=new T.CubeCamera(.18,220,target);probe.position.fromArray(position);world.add(probe);try{world.updateMatrixWorld(true);if(world===scene&&!shadowsReady)renderer.shadowMap.needsUpdate=true;probe.update(renderer,world);if(world===scene)shadowsReady=true;return pmrem.fromCubemap(target.texture);}finally{probe.removeFromParent();target.dispose();}}
 const w=water.visible,v=wetVeranda.visible;water.visible=wetVeranda.visible=false;
 try{skyEnvironment=capture(skyScene,[0,0,0]);scene.environment=skyEnvironment.texture;scene.environmentIntensity=.95;courtEnvironment=capture(scene,[1.5,4.1,4]);
  for(const m of materials)if(!m.userData.nightVolume203&&(m.metalness>.30||m.userData.metricTimberGrain)){m.envMap=courtEnvironment.texture;m.envMapRotation.set(0,0,0);m.envMapIntensity=m.metalness>.30?.75:.48;m.needsUpdate=true;targets.push(m.name);}
  for(const[label,pose,p]of[['hall',HALL_ENVELOPE143,[0,5.8,6.8]],['pagoda',PAGODA_FRAME143,[0,7.86,2.60]],['veranda',{position:[0,0,0],yaw:0,scale:[1,1,1]},[4.6,3.1,29.5]]]){const position=transformed(pose,p).toArray(),environment=capture(scene,position);volumeEnvironments.push(environment);const assigned=[];for(const m of materials)if(m.userData.nightVolume203===label){m.envMap=environment.texture;m.envMapRotation.set(0,0,0);m.envMapIntensity=1;m.needsUpdate=true;assigned.push(m.name);}volumes.push({label,position,resolution:128,materials:assigned,scope:'Approximate actual one-bounce local radiance, not a projected facade light'});}
 }finally{water.visible=w;wetVeranda.visible=v;pmrem.dispose();renderer.shadowMap.needsUpdate=true;}
 return{info:{position:[1.5,4.1,4],resolution:128,actualSkyAndCourtCaptures:true,ceramicUsesExteriorCobalt:true,restrainedCourtMaterials:targets,localBuildingRadiance:volumes,photoSampled:false,visualAccepted:false},dispose(){skyEnvironment.dispose();courtEnvironment.dispose();for(const e of volumeEnvironments)e.dispose();}};
}
