// A genuine planar scene capture with small nonparallel gravity-wave slopes.
// No regular luminance stripes, warm-pixel gain or painted reflection streaks.
export const pondFragment203=`uniform sampler2D tDiffuse;uniform vec3 color;uniform float time;varying vec4 vUv;varying vec3 vWorld;
void main(){vec2 uv=vUv.xy/vUv.w;float a=vWorld.x*.53+vWorld.z*.81+time*.27,b=-vWorld.x*1.11+vWorld.z*.37-time*.19,c=vWorld.x*1.97+vWorld.z*2.63+time*.42;
vec2 gradient=vec2(.53,.81)*cos(a)*.006+vec2(-1.11,.37)*cos(b)*.002+vec2(1.97,2.63)*cos(c)*.0004;gradient+=vec2(9.7,11.3)*cos(vWorld.x*9.7+vWorld.z*11.3+time*.8)*.00035+vec2(-18.1,5.3)*cos(-vWorld.x*18.1+vWorld.z*5.3-time*1.1)*.00017+vec2(3.9,27.3)*cos(vWorld.x*3.9+vWorld.z*27.3+time*.9)*.00008;vec2 slope=gradient*.22;uv+=slope;
vec3 r=texture2D(tDiffuse,uv).rgb*.56;r+=texture2D(tDiffuse,uv+slope*.18+vec2(.00020,-.00012)).rgb*.22;r+=texture2D(tDiffuse,uv-slope*.18-vec2(.00020,-.00012)).rgb*.22;
vec3 waveNormal=normalize(vec3(-gradient.x,1.,-gradient.y));float nDotV=clamp(abs(dot(normalize(cameraPosition-vWorld),waveNormal)),0.,1.);float fresnel=.02037+.97963*pow(1.-nDotV,5.);vec3 water=color*(1.-fresnel)*.35+r*fresnel;gl_FragColor=vec4(water,1.);
#include <tonemapping_fragment>
#include <colorspace_fragment>
}`;

export const wetVerandaFragment203=`uniform sampler2D tDiffuse;uniform sampler2D roughMap;uniform vec3 color;varying vec4 rUv;varying vec2 pUv;varying vec3 wPos;
void main(){vec2 u=rUv.xy/rUv.w;float rough=texture2D(roughMap,pUv*.42).g;vec2 offset=vec2(sin(wPos.x*3.7+wPos.z*1.1),cos(wPos.z*4.3-wPos.x*2.1))*.00028;vec3 r=texture2D(tDiffuse,u+offset).rgb*.60;r+=texture2D(tDiffuse,u-offset+vec2(.00022,.00014)).rgb*.20;r+=texture2D(tDiffuse,u-offset-vec2(.00022,.00014)).rgb*.20;
float wet=clamp(.25+.85*(1.-rough),.22,.98);float cosView=clamp(abs(normalize(cameraPosition-wPos).y),0.,1.);float fresnel=.02037+.97963*pow(1.-cosView,5.);gl_FragColor=vec4(r,clamp(fresnel*wet,.020,.90));
#include <tonemapping_fragment>
#include <colorspace_fragment>
}`;
