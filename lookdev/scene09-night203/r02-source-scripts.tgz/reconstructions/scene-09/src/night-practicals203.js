import * as T from 'three';
import{HALL_ENVELOPE143}from'./hall-envelope143.js';
import{PAGODA_FRAME143}from'./pagoda-frame143.js';
export const NIGHT203_REVISION='scene09-bounded-practical-cobalt-night203-r02';
const transformed=(pose,p)=>new T.Vector3(...p).applyMatrix4(new T.Matrix4().compose(new T.Vector3(...pose.position),new T.Quaternion().setFromAxisAngle(new T.Vector3(0,1,0),pose.yaw),new T.Vector3(...pose.scale)));

export function withNightVolume203(M,materials,label,fn){const held={};for(const k of['red','wood','dark','eaveDark','carvedTimber','ivory','gold','bronze','darkGilt','sanctuaryGilt']){const old=M[k];if(!old)continue;held[k]=old;const m=old.clone();m.name='scene09-203-'+label+'-'+k;m.onBeforeCompile=old.onBeforeCompile;m.customProgramCacheKey=old.customProgramCacheKey;m.userData={...old.userData,nightVolume203:label};materials.push(m);M[k]=m;}try{return fn();}finally{Object.assign(M,held);}}

export function configurePracticals203({scene,fixtures,moon,fill,warmKey,materials,M}){
 // Existing fixture positions and physical assemblies are untouched. Small
 // secondary lamps have local smooth cutoffs; primary pools receive actual
 // geometry shadows within the native sampler budget.
 scene.remove(fill);for(const o of[...scene.children])if(o.isHemisphereLight||o.isRectAreaLight)scene.remove(o);
 moon.intensity=1.30;moon.shadow.radius=3.2;moon.name='scene09-203-cool-night-key';
 for(const o of[...scene.children])if(o.isPointLight&&!fixtures.includes(o)){
  if(o.distance>3.9||!o.distance)scene.remove(o);else{o.intensity*=.7;o.castShadow=false;}
 }
 for(const o of[...scene.children])if(o.isSpotLight&&o!==warmKey&&!o.name.includes('finial')){scene.remove(o);if(o.target)scene.remove(o.target);}
 const records=[],chosen=new Set();
 function closest(p,label,filter=()=>true){const q=fixtures.filter(l=>!chosen.has(l)&&filter(l)).sort((a,b)=>a.position.distanceToSquared(p)-b.position.distanceToSquared(p))[0];if(q){chosen.add(q);q.userData.pool203=label;}}
 closest(new T.Vector3(1,7.2,23.7),'near-west-modeled-lantern');closest(new T.Vector3(7.7,7.3,21.6),'near-east-modeled-lantern');
 const stone=fixtures.find(l=>l.userData.stoneHero158);if(stone){chosen.add(stone);stone.userData.pool203='hero158-stone-chamber';}
 for(const x of[-4.8,4.8])closest(transformed(HALL_ENVELOPE143,[x,6.1,5.4]),'main-hall-portal-'+x,l=>l.position.z<0&&l.position.y>4);
 closest(transformed(PAGODA_FRAME143,[0,5.4,3.7]),'pagoda-occupied-gallery',l=>l.position.x< -5);
 for(const l of fixtures){const source=l.userData.source203||{},near=l.position.z>15,primary=chosen.has(l),hero=!!l.userData.stoneHero158,chamberAnchor=l.position.toArray();
  if(primary){const role=l.userData.pool203,pose=role.startsWith('main-hall')?HALL_ENVELOPE143:role.startsWith('pagoda')?PAGODA_FRAME143:null,front=pose?new T.Vector3(Math.sin(pose.yaw),0,Math.cos(pose.yaw)).multiplyScalar(-1):new T.Vector3(...(source.worldFront||[0,0,1])),size=source.assemblyScale||1,r=hero?.49*size:source.requestedIntensity>=38?.37*size:.36*Math.sqrt((source.requestedIntensity||1)/24.5)*size;l.position.addScaledVector(front,r*1.05);l.intensity*=near?1.20:hero?1.45:pose===PAGODA_FRAME143?2.8:1.65;}
  const requested=source.worldReach||5,reach=primary?(near?15:hero?9:10):near?8:Math.min(4.8,Math.max(2.0,requested));l.distance=reach;l.decay=2;
  if(!primary&&!near)l.intensity*=.55;
  l.castShadow=primary;if(primary){l.shadow.mapSize.set(hero?768:512,hero?768:512);l.shadow.camera.near=hero?.06:.10;l.shadow.camera.far=reach;l.shadow.bias=-.000025;l.shadow.normalBias=hero?.008:.012;l.shadow.radius=12.0;}
  records.push({chamberAnchor,position:l.position.toArray(),intensity:l.intensity,reach,decay:l.decay,geometryShadow:l.castShadow,role:l.userData.pool203||'secondary-modeled-local-lantern',sourceApproximation:primary?'Aggregate radiance exiting the modeled paper face; not a point bulb blocked by the entire case':'Local secondary fixture',originalRequested:source});
 }
 // Preserve every original paper texture, but keep room transoms below the
 // visible lantern chambers in radiance. No architectural skin emits light.
 M.windowPaper.emissiveIntensity=.55;M.pagodaPaper.emissiveIntensity=.70;M.stonePaper.emissiveIntensity=.90;
 for(const m of materials)if(m.emissive&&m!==M.glow&&m.emissiveMap!==M.paper.emissiveMap&&!/paper|washi/i.test(m.name))m.emissiveIntensity=0;
 M.glow.emissiveIntensity=.65;
 return{revision:NIGHT203_REVISION,practicals:records,removedFacadeAreaWash:true,removedWarmDirectionalFill:true,removedUnmodeledGardenGrazes:true,paper:{lantern:M.paper.emissiveIntensity,room:M.windowPaper.emissiveIntensity,pagoda:M.pagodaPaper.emissiveIntensity,stone:M.stonePaper.emissiveIntensity},shadowScope:'Dominant modeled practicals and retained cool/shrine/finial sources; secondary fixtures use bounded smooth local falloff',exactAreaEmitterOrPathTracedGI:false,referenceImageSampled:false,visualAccepted:false};
}

// Sky and courtyard are genuinely captured native radiance. Ceramic receives
// the cobalt exterior field; metal/wood retain a restrained court reflection.
export function captureNight203({renderer,scene,sky,water,wetVeranda,materials}){
 const pmrem=new T.PMREMGenerator(renderer),skyScene=new T.Scene(),skyCopy=new T.Mesh(sky.geometry,sky.material);skyScene.add(skyCopy);let skyEnvironment,courtEnvironment;const targets=[],volumes=[],volumeEnvironments=[];
 function capture(world,position){const target=new T.WebGLCubeRenderTarget(128,{type:T.HalfFloatType,generateMipmaps:false}),probe=new T.CubeCamera(.18,220,target);probe.position.fromArray(position);world.add(probe);try{world.updateMatrixWorld(true);renderer.shadowMap.needsUpdate=true;probe.update(renderer,world);return pmrem.fromCubemap(target.texture);}finally{probe.removeFromParent();target.dispose();}}
 const w=water.visible,v=wetVeranda.visible;water.visible=wetVeranda.visible=false;
 try{skyEnvironment=capture(skyScene,[0,0,0]);scene.environment=skyEnvironment.texture;scene.environmentIntensity=.95;courtEnvironment=capture(scene,[1.5,4.1,4]);
  for(const m of materials)if(!m.userData.nightVolume203&&(m.metalness>.30||m.userData.metricTimberGrain)){m.envMap=courtEnvironment.texture;m.envMapRotation.set(0,0,0);m.envMapIntensity=m.metalness>.30?.75:.48;m.needsUpdate=true;targets.push(m.name);}
  for(const[label,pose,p]of[['hall',HALL_ENVELOPE143,[0,5.8,6.8]],['pagoda',PAGODA_FRAME143,[0,7.86,2.60]]]){const position=transformed(pose,p).toArray(),environment=capture(scene,position);volumeEnvironments.push(environment);const assigned=[];for(const m of materials)if(m.userData.nightVolume203===label){m.envMap=environment.texture;m.envMapRotation.set(0,0,0);m.envMapIntensity=1;m.needsUpdate=true;assigned.push(m.name);}volumes.push({label,position,resolution:128,materials:assigned,scope:'Approximate actual one-bounce local radiance, not a projected facade light'});}
 }finally{water.visible=w;wetVeranda.visible=v;pmrem.dispose();renderer.shadowMap.needsUpdate=true;}
 return{info:{position:[1.5,4.1,4],resolution:128,actualSkyAndCourtCaptures:true,ceramicUsesExteriorCobalt:true,restrainedCourtMaterials:targets,localBuildingRadiance:volumes,photoSampled:false,visualAccepted:false},dispose(){skyEnvironment.dispose();courtEnvironment.dispose();for(const e of volumeEnvironments)e.dispose();}};
}
