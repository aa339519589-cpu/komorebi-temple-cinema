// A genuine planar scene capture with small nonparallel gravity-wave slopes.
// No regular luminance stripes, warm-pixel gain or painted reflection streaks.
export const pondFragment203=`uniform sampler2D tDiffuse;uniform vec3 color;uniform float time;varying vec4 vUv;varying vec3 vWorld;
void main(){vec2 uv=vUv.xy/vUv.w;float a=vWorld.x*.53+vWorld.z*.81+time*.27,b=-vWorld.x*1.11+vWorld.z*.37-time*.19,c=vWorld.x*1.97+vWorld.z*2.63+time*.42;
vec2 gradient=vec2(.53,.81)*cos(a)*.006+vec2(-1.11,.37)*cos(b)*.002+vec2(1.97,2.63)*cos(c)*.0004;vec2 slope=gradient*.22;uv+=slope;
vec3 r=texture2D(tDiffuse,uv).rgb*.56;r+=texture2D(tDiffuse,uv+slope*.18+vec2(.00020,-.00012)).rgb*.22;r+=texture2D(tDiffuse,uv-slope*.18-vec2(.00020,-.00012)).rgb*.22;
vec3 waveNormal=normalize(vec3(-gradient.x,1.,-gradient.y));float nDotV=clamp(abs(dot(normalize(cameraPosition-vWorld),waveNormal)),0.,1.);float fresnel=.02037+.97963*pow(1.-nDotV,5.);vec3 water=color*(1.-fresnel)*.35+r*fresnel;gl_FragColor=vec4(water,1.);
#include <tonemapping_fragment>
#include <colorspace_fragment>
}`;
