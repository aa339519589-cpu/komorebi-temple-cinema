import * as T from 'three';
import {HALL_ENVELOPE143 as H} from './hall-envelope143.js';

export const REBUILD221_REVISION='scene09-masonry-arch-and-lantern-court221-r01';
const V=a=>new T.Vector3(...a);
const world=(p)=>V(p).applyMatrix4(new T.Matrix4().compose(V(H.position),new T.Quaternion().setFromAxisAngle(V([0,1,0]),H.yaw),V(H.scale)));

// The comparison resolves a masonry arch carrying the red railing. The old
// central timber bent closed its water opening. These are complete wedge
// stones across the barrel, with a continuous open intrados and real mortar
// gaps; neither the arch nor its lighting depends on a viewing direction.
export function buildMasonryGardenBridge221({emit,box,between,lantern,materials:M},ownedMaterials){
 const deck=x=>1.25+1.36*Math.pow(Math.max(0,1-(x/8)**2),1.15);
 const soffit=x=>.15+1.90*Math.sqrt(Math.max(0,1-(x/8.15)**2));
 const masonry=new T.MeshPhysicalMaterial({name:'scene09-221-wet-cut-granite-arch',color:new T.Color().setRGB(1.10,1.10,1.04),map:M.cutStone.map,normalMap:M.cutStone.normalMap,normalScale:new T.Vector2(.28,.28),roughnessMap:M.cutStone.roughnessMap,roughness:.85,clearcoat:.23,clearcoatRoughness:.31,metalness:0});
 const mortar=new T.MeshStandardMaterial({name:'scene09-221-recessed-damp-lime-mortar',color:0x242923,roughness:1,metalness:0});ownedMaterials.push(masonry,mortar);
 function wedge(x0,x1,z0,z1,material,tone=1){
  const p=[],uv=[],ix=[],N=4;
  for(let j=0;j<=N;j++){
   const x=x0+(x1-x0)*j/N,lo=soffit(x),hi=deck(x)-.115;
   for(const[y,z]of[[lo,z0],[hi,z0],[hi,z1],[lo,z1]]){p.push(x,y,z);uv.push(z*1.3,x*1.3+y*.4);}
  }
  for(let j=0;j<N;j++)for(let k=0;k<4;k++){const q=(k+1)%4,a=j*4+k,b=j*4+q,c=(j+1)*4+q,d=(j+1)*4+k;ix.push(a,b,c,a,c,d);}
  ix.push(0,2,1,0,3,2,N*4,N*4+1,N*4+2,N*4,N*4+2,N*4+3);
  const g=new T.BufferGeometry();g.name='scene09-221-closed-masonry-arch-voussoir';g.setAttribute('position',new T.Float32BufferAttribute(p,3));g.setAttribute('uv',new T.Float32BufferAttribute(uv,2));g.setIndex(ix);g.computeVertexNormals();emit(g,material,0,0,0,1,1,1,0,tone);
 }
 // Seven longitudinal courses cross fifty-two arch segments. Staggered
 // joints remain separate solid stones, including the underside of the arch.
 let stoneCount=0;const half=8.0,step=16/52;
 for(let row=0;row<7;row++){
  const z0=-.02+row*3.24/7,z1=z0+3.24/7-.012,offset=row%2?step*.5:0;
  for(let j=-1;j<53;j++){
   const a=Math.max(-half,-half+j*step+offset)+.008,b=Math.min(half,-half+(j+1)*step+offset)-.008;if(b<=a)continue;
   wedge(a,b,z0,z1,masonry,.79+.19*(.5+.5*Math.sin(j*7.31+row*11.7)));stoneCount++;
  }
 }
 // Closed blocks and low returns carry both landing ends into the rock bank.
 for(const side of[-1,1])for(let course=0;course<3;course++)for(let j=0;j<4;j++){
  const x=side*(7.78+course*.12),z=.10+j*.95+(course%2?-.19:0);
  box(x,.21+course*.28,z,.94,.264,.91,masonry,0,.79+.13*Math.sin(j*2.7+course)**2);
 }
 for(let i=0;i<58;i++){
  const x=-8+(i+.5)*16/58,a=-8+i*16/58,b=a+16/58,angle=Math.atan((deck(b)-deck(a))/(b-a));
  box(x,deck(x)-.045,1.60,16/58-.012,.12,3.18,M.bridgeDeck,[0,0,angle],.84+.12*Math.sin(i*1.71)**2);
 }
 // Scarfed arch rails retain their own curved rectangular section and the
 // actual openings through the baluster posts. All through-mortises are solid
 // cheeks around the rail; no straight handrail floats over the arch.
 function rail(z,width,offset,depth,material,bevel=.008){
  const s=new T.Shape();for(let i=0;i<=80;i++){const x=-8+i*.2;i?s.lineTo(x,deck(x)+offset):s.moveTo(x,deck(x)+offset);}for(let i=80;i>=0;i--){const x=-8+i*.2;s.lineTo(x,deck(x)+offset-depth);}s.closePath();
  const g=new T.ExtrudeGeometry(s,{depth:width,steps:1,bevelEnabled:true,bevelSize:bevel,bevelThickness:bevel,bevelSegments:2,curveSegments:1});g.translate(0,0,z-width/2);g.name='scene09-221-closed-arched-vermilion-rail';emit(g,material);
 }
 const finial=new T.LatheGeometry([[0,0],[.095,0],[.105,.035],[.08,.08],[.125,.14],[.13,.22],[.09,.29],[.035,.34],[0,.39]].map(p=>new T.Vector2(...p)),24);
 for(const z of[.17,3.03]){
  rail(z,.22,1.025,.16,M.bridgeRed,.014);rail(z,.15,.61,.10,M.bridgeRed);rail(z,.17,.28,.11,M.bridgeRed);rail(z,.205,.865,.028,M.bridgeTimber,.003);
  for(let i=0;i<=12;i++){
   const x=-8+i*16/12,y=deck(x);
   for(const[lo,hi]of[[-.045,.17],[.28,.51],[.61,.865],[1.025,1.125]])box(x,y+(lo+hi)/2,z,.235,hi-lo,.25,M.bridgeRed);
   for(const side of[-1,1])box(x,y+.54,z+side*.114,.235,1.17,.029,M.bridgeRed);
   box(x,y+.04,z,.30,.12,.30,M.bridgeTimber);box(x,y+1.16,z,.31,.10,.31,M.bridgeRed);box(x,y+1.22,z,.21,.03,.23,M.bronze);emit(finial,M.gold,x,y+1.235,z,.74,.74,.74);
   if(i<12)for(const t of[1/3,2/3]){const xx=x+16/12*t;box(xx,deck(xx)+.575,z,.06,.58,.08,M.bridgeRed);}
  }
 }
 // A small existing case hangs from a real bracket fixed into the intrados.
 lantern(0,1.35,1.60,.40);between([0,1.78,1.60],[0,soffit(0)-.015,1.60],.017,.017,M.bronze,true);box(0,soffit(0)-.018,1.60,.22,.035,.22,M.bronze);
 return{revision:REBUILD221_REVISION,structure:'Open masonry barrel arch carrying timber deck and mortised vermilion rails',barrelStoneCount:stoneCount,abutmentBlocks:24,intradosCrown:soffit(0),deckCrown:deck(0),centrePier:false,closedGeometry:true,dimensionsInferred:true,referencePixelsSampled:false,visualAccepted:false};
}

// Source and surface calibration, executed before finite-emitter shader
// installation so the native shadow/point ordering remains explicit.
export function configureCourt221({scene,materials,fixtures,night203}){
 const changes=[],sources=[];
 for(const m of materials){
  if(m.name==='scene09-203-hall-wood'){m.color.setRGB(2.05,1.44,.88);m.clearcoat=.065;m.clearcoatRoughness=.87;changes.push(m.name);}
  if(m.name==='scene09-203-hall-red'){m.color.setRGB(3.35,1.86,1.16);m.clearcoat=.12;m.clearcoatRoughness=.75;changes.push(m.name);}
  if(m.name==='scene09-203-hall-ivory'){m.color.setHex(0x9c907a);changes.push(m.name);}
  if(m.name==='scene09-licensed-leaf-and-groundcover145'){m.color.setHex(0xbdc8a7);m.roughness=1;m.clearcoat=.035;m.clearcoatRoughness=.65;m.specularIntensity=.32;m.normalScale.set(.42,.42);changes.push(m.name);}
  if(m.name.startsWith('scene09-cc0-scanned-fixture-foundation-')){m.color.setRGB(.84,.88,.83);m.roughness=.93;changes.push(m.name);}
  if(m.name==='scene09-bridge-vermilion-coating'){m.color.setRGB(4.6,2.20,1.43);m.clearcoat=.22;m.clearcoatRoughness=.32;changes.push(m.name);}
 }
 // Replace two exterior paper-exit point proxies by wide, geometry-shadowed
 // cones at the same actual case faces. The small centre bulbs remain local
 // to the chamber; the body no longer receives a point singularity from a
 // source floating in front of it. These cones are a native approximation
 // to paper-face transport, not additional invisible courtyard fill lights.
 for(const l of fixtures){
  const role=l.userData.pool203;
  if(role==='hero158-stone-chamber'||role==='east158-stone-chamber'){
   const record=night203.practicals.find(p=>p.role===role),centre=V(record.chamberAnchor),front=V(l.userData.source203.worldFront),radius=(role==='hero158-stone-chamber'?.44:.40)*(l.userData.source203.assemblyScale||1),p=centre.clone().addScaledVector(front,radius+.018),target=role==='hero158-stone-chamber'?V([-4.4,.32,11.3]):V([8.6,.38,10.3]);
   l.position.copy(centre);l.castShadow=false;l.intensity=role==='hero158-stone-chamber'?15:12;l.distance=2.8;
   const cone=new T.SpotLight(0xffffff,role==='hero158-stone-chamber'?190:165,12,1.08,.82,2);cone.color.setRGB(1,.64,.31);cone.position.copy(p);cone.target.position.copy(target);cone.name='scene09-221-'+role+'-paper-face-transport';cone.castShadow=true;cone.shadow.mapSize.set(768,768);cone.shadow.camera.near=.10;cone.shadow.camera.far=12;cone.shadow.bias=-.000025;cone.shadow.normalBias=.012;cone.shadow.radius=4;cone.userData.source221={actualCaseFace:true,paperAreaApproximation:true};scene.add(cone,cone.target);
   sources.push({name:cone.name,chamber:centre.toArray(),position:p.toArray(),target:target.toArray(),candela:cone.intensity,geometryShadow:true,source:'Existing visible modeled square paper case; wide outgoing paper-face cone'});
  }
  if(l.userData.source203?.kind==='bridge-post203'){
   const west=l.position.x<0;l.intensity=west?62:78;l.distance=8;l.castShadow=west;if(west){l.shadow.mapSize.set(768,768);l.shadow.camera.near=.06;l.shadow.camera.far=8;l.shadow.bias=-.000025;l.shadow.normalBias=.009;l.shadow.radius=4;}
   sources.push({name:west?'bridge-west-case':'bridge-east-case',position:l.position.toArray(),candela:l.intensity,reach:l.distance,geometryShadow:l.castShadow,source:'Actual mounted bridge case centre'});
  }
 }
 scene.traverse(o=>{
  if(o.name==='scene09-203-original-underbridge-case-source'){o.castShadow=false;o.intensity=24;o.distance=5;}
  if(o.name==='scene09-203-west-entry-hooded-practical-finite-cone'){o.target.position.copy(world([-1.1,4.75,1.30]));o.intensity=265;o.distance=12;o.angle=.83;o.penumbra=.85;sources.push({name:o.name,position:o.position.toArray(),target:o.target.position.toArray(),candela:o.intensity,geometryShadow:true,source:'Existing closed joist-mounted bronze hood; re-aimed through the open altar portal'});}
 });
 return{revision:REBUILD221_REVISION,changes,sources,exposureChanged:false,emissiveArchitecture:false,shadowCount:scene.children.filter(o=>o.isLight&&o.castShadow).length,limitations:['Paper cones remain finite native source approximations.','Other secondary lamps and the underbridge case have no full geometry shadow.','SH and planar reflections are retained native approximations.'],visualAccepted:false};
}
