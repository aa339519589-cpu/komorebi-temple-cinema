// A low architectural close opens beneath the carried main eaves. The
// retreat reveals the bridge, tower and water before the fixed reference pose.
export const SCENE09_REFERENCE144={position:[6,2.7,33],target:[0,5.5,-10],fov:52};
export const SCENE09_SHOT144={
 points:[[6.8,1.45,8],[8.6,1.8,14],[7.8,2.2,25],[6,2.7,33]],
 nearTarget:[6.3,10.8,-14],
 intent:'Low 1.45m architectural opening from the unobstructed pond corridor, followed by a retreat revealing the bridge, tower and water, ending at the unchanged photographic comparison camera. Actual intermediate obstruction review remains required.',
 revision:'scene09-low-architecture-reveal221-r02'
};
