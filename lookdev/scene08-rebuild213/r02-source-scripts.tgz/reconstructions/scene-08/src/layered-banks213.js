import * as T from 'three';

// A fixed physical waterline darkens the same mineral surface where it is
// damp. It follows world geometry in every camera, not a screen-space mask.
export function installDampStone213(material){
 const old=material.onBeforeCompile,key=material.customProgramCacheKey.bind(material);
 const mineralMap213=T.ShaderChunk.map_fragment.replace('diffuseColor *= sampledDiffuseColor;',`float mineralLuma213=dot(sampledDiffuseColor.rgb,vec3(.2126,.7152,.0722));
 float sourceMoss213=smoothstep(.95,1.32,sampledDiffuseColor.g/max(.006,sampledDiffuseColor.r));
 sampledDiffuseColor.rgb=mix(mineralLuma213*vec3(1.05,1.04,.98),sampledDiffuseColor.rgb,sourceMoss213*.88);
 diffuseColor *= sampledDiffuseColor;`);
 material.onBeforeCompile=s=>{old.call(material,s);s.vertexShader=s.vertexShader.replace('#include <common>','#include <common>\nvarying float stoneWorldY213;').replace('#include <project_vertex>',`#include <project_vertex>
 vec4 stonePosition213=vec4(transformed,1.);
 #ifdef USE_INSTANCING
 stonePosition213=instanceMatrix*stonePosition213;
 #endif
 stoneWorldY213=(modelMatrix*stonePosition213).y;`);s.fragmentShader=s.fragmentShader.replace('#include <common>','#include <common>\nvarying float stoneWorldY213;').replace('#include <map_fragment>',mineralMap213).replace('#include <color_fragment>','#include <color_fragment>\ndiffuseColor.rgb*=mix(.61,1.,smoothstep(.55,1.00,stoneWorldY213));').replace('#include <roughnessmap_fragment>','#include <roughnessmap_fragment>\nroughnessFactor*=mix(.60,1.,smoothstep(.55,1.00,stoneWorldY213));');};
 material.customProgramCacheKey=()=>key()+'-world-waterline213';material.needsUpdate=true;
}

function fernGeometry(){
 const p=[];function tri(a,b,c){p.push(...a,...b,...c);}const point=(a,t,L,h)=>new T.Vector3(Math.cos(a)*L*t,h*Math.sin(t*Math.PI*.82),Math.sin(a)*L*t);
 for(let f=0;f<9;f++){
  const a=f*2.399963,L=.28+.11*(.5+.5*Math.sin(f*1.73)),h=.21+.09*(.5+.5*Math.cos(f*2.3)),side=new T.Vector3(-Math.sin(a),0,Math.cos(a));
  for(let j=1;j<16;j++)for(const sign of[-1,1]){
   const t=j/17,c=point(a,t,L,h),reach=(.075*Math.sin(t*Math.PI)**.65+.008)*(1-.30*t),tip=c.clone().addScaledVector(side,sign*reach).add(new T.Vector3(Math.cos(a)*.026,.004,Math.sin(a)*.026)),half=.008*(1-.60*t),forward=new T.Vector3(Math.cos(a)*half,0,Math.sin(a)*half),mid=c.clone().lerp(tip,.54).add(new T.Vector3(0,.004,0)),l=mid.clone().sub(forward),r=mid.clone().add(forward);tri(c.toArray(),l.toArray(),tip.toArray());tri(c.toArray(),tip.toArray(),r.toArray());
  }
  for(let j=0;j<12;j++){const c=point(a,j/12,L,h),d=point(a,(j+1)/12,L,h),w=.0018*(1-j/15);tri(c.clone().addScaledVector(side,w).toArray(),c.clone().addScaledVector(side,-w).toArray(),d.clone().addScaledVector(side,w*.7).toArray());tri(c.clone().addScaledVector(side,-w).toArray(),d.clone().addScaledVector(side,-w*.7).toArray(),d.clone().addScaledVector(side,w*.7).toArray());}
 }
 const g=new T.BufferGeometry();g.setAttribute('position',new T.Float32BufferAttribute(p,3));g.computeVertexNormals();return g;
}

export function dressLayeredBanks213({emit,scannedStones,botany,height,riverXAt,materials}){
 const fern=new T.MeshStandardMaterial({name:'scene08-213-fine-curved-fern-fronds',color:0x526e35,roughness:.86,metalness:0,side:T.DoubleSide}),fernG=fernGeometry();materials.push(fern);const rocks=[],shrubs=[],ferns=[];
 const stones=[[-1.35,.60,1.75,1.60,3],[-.55,-2.7,1.60,1.45,3],[-2.65,2.4,1.25,.80,0],[-3.05,-1.7,1.35,.90,2],[4.05,3.8,1.48,1.00,5],[3.8,1.3,1.20,.85,1],[4.65,-3.7,1.35,.90,3],[2.8,-6.5,1.15,.90,2]];
 for(const[x,z,width,h,index]of stones){scannedStones.place({emit,x,z,height:height(x,z),width,heightLimit:h,index,allowTall:true});rocks.push({x,z,width,heightLimit:h,index});}
 for(const[x,z,width,index]of[[-2.8,-.9,1.15,0],[-1.9,-2.8,1.05,2],[-3.7,1.6,.92,1],[-1.6,3.3,.85,3],[4.25,2.1,1.02,2],[4.8,-2.8,1.20,1],[3.7,-5.0,1.05,3],[1.8,-8.0,.82,0]]){botany.place({emit,height,x,z,width,flower:false,index,yaw:index*.71});shrubs.push({x,z,width,index});}
 for(let i=0;i<36;i++){const z=-8.5+(i/35)*14.8,side=i%2?1:-1,x=riverXAt(z)+side*(1.50+.30*Math.sin(i*1.7)),scale=.62+.30*(.5+.5*Math.sin(i*2.13)),y=height(x,z)+.018;emit(fernG,fern,x,y,z,scale,scale,scale,[0,i*2.399,0]);ferns.push([x,y,z,scale]);}
 return{revision:'scene08-layered-granite-understory213-r01',rocks,shrubs,fernRootCount:ferns.length,fernRoots:ferns,source:'Existing immutable CC0 moss-rock/shrub geometry; new actual curved fern leaflets and world-rooted placement',newExternalAssets:false,visualAccepted:false};
}
