import * as T from 'three';
import {carvedTimber197} from './natural-joinery197.js';
import {createSteppedReceiver213} from './garden-joinery213.js';

// A lower, wider ridge and a shorter rising return belong to one physical
// four-panel roof. The reference camera is not used to form this surface.
export function createGrandRoofProfile213({frame,w,d,eave,rise,curl,ridgeRatio}){
 const hw=w/2,hd=d/2,rh=w*ridgeRatio,peak=eave+rise,c=Math.cos(frame.yaw),s=Math.sin(frame.yaw),local=([x,y,z])=>{const dx=x-frame.x,dz=z-frame.z;return new T.Vector3(c*dx-s*dz,y,s*dx+c*dz);},edge=new T.CatmullRomCurve3([new T.Vector3(hw,eave,hd),local([.08,9.46,-4.95]),local([1.18,8.93,-6.85]),local([2.75,8.30,-9.15])],false,'centripetal');
 const ridge=u=>[u*rh,peak+.25*Math.pow(Math.abs(u),6)-.16*(1-u*u),0];
 function point(side,t,u){const far=edge.getPoint(1);let boundary,top;
  if(side===0){boundary=new T.Vector3(u*hw,eave+.40*(1-u)/2-.09*(1-u*u),hd);top=new T.Vector3(...ridge(u));}
  else if(side===1){boundary=edge.getPoint((1-u)/2);top=new T.Vector3(...ridge(1));}
  else if(side===2){const f=(u+1)/2;boundary=new T.Vector3(-hw+(far.x+hw)*f,eave+(far.y-eave)*f,-hd+(far.z+hd)*f);top=new T.Vector3(...ridge(u));}
  else{boundary=new T.Vector3(-hw,eave+.40*(u+1)/2-.09*(1-u*u),u*hd);top=new T.Vector3(...ridge(-1));}
  const p=top.clone().lerp(boundary,t);p.y=boundary.y+(top.y-boundary.y)*Math.pow(Math.max(0,1-t),1.65)+curl*Math.pow(t,10)*(.18+.82*Math.pow(Math.abs(u),7));return p.toArray();
 }
 return{point,ridge,info:{revision:'scene08-broad-cambered-ridge-short-return213-r05',ridgeSpan:rh*2,returnWorldAnchors:[[.08,9.46,-4.95],[1.18,8.93,-6.85],[2.75,8.30,-9.15]],referencePixelsUsed:false,visualAccepted:false}};
}

// Thin real timber with a curved waist and squared bearing nose. This is
// carved solid geometry, replacing the old 350mm-deep flying blocks.
const armCache=new Map();
export function createFineCantilever213(length,rise=.015,depth=.18){
 const key=[length,rise,depth].map(v=>v.toFixed(4)).join(',');if(armCache.has(key))return armCache.get(key);
 const L=length,R=rise,q=new T.Shape();q.moveTo(-.12,.065);q.lineTo(L,R+.065);q.lineTo(L,R-.020);q.lineTo(L-.035,R-.020);q.lineTo(L-.035,R-.045);q.bezierCurveTo(L-.11,R-.050,L-.15,R-.088,L-.23,R-.090);q.bezierCurveTo(L*.48,R*.48-.090,L*.21,-.075,-.12,-.075);q.closePath();
 const g=carvedTimber197(q,depth,[[[L-.055,R+.012],[L*.64,R*.64-.035],[.04,-.042]]],'scene08-213-fine-waisted-carved-bearing-arm');g.userData.fineHall213=true;armCache.set(key,g);return g;
}

// The part indices retain the six crossed-arm slots used by actual fitted
// cast end sleeves. The new kit has a 1.05m envelope and a .49m upper plane.
export function createFineHallJoinery213(){
 const parts=[],resources=new Set(),add=(g,material='red',p=[0,0,0],yaw=0)=>{const q=g.clone();q.rotateY(yaw);q.translate(...p);parts.push({geometry:q,material});resources.add(q);return q;},block=(w,h,d)=>createSteppedReceiver213(w,h,d,.70);
 const crossArm=(span,depth,notch='none')=>{const h=span/2,q=new T.Shape();q.moveTo(-h,.065);if(notch==='top'){q.lineTo(-.09,.065);q.lineTo(-.09,-.005);q.lineTo(.09,-.005);q.lineTo(.09,.065);}q.lineTo(h,.065);q.lineTo(h,-.020);q.lineTo(h-.035,-.020);q.bezierCurveTo(h-.13,-.025,h-.16,-.085,.09,-.090);if(notch==='bottom'){q.lineTo(.09,-.005);q.lineTo(-.09,-.005);q.lineTo(-.09,-.090);}else q.lineTo(-.09,-.090);q.bezierCurveTo(-h+.16,-.085,-h+.13,-.025,-h+.035,-.020);q.lineTo(-h,-.020);q.closePath();return carvedTimber197(q,depth,[[[-h+.055,.012],[-h*.50,-.035],[0,-.048]],[[h-.055,.012],[h*.50,-.035],[0,-.048]]],'scene08-213-fine-half-lapped-cross-arm');};
 add(block(.56,.14,.56),'red',[0,-.14,0]);
 add(crossArm(.88,.16,'top'),'red',[0,.055,0]);add(crossArm(.88,.16,'bottom'),'red',[0,.055,0],Math.PI/2);
 for(const side of[-1,1]){add(block(.17,.12,.17),'red',[side*.26,.105,0]);add(block(.17,.12,.17),'red',[0,.105,side*.26]);}
 const upper=crossArm(.96,.15);for(const side of[-1,1]){add(upper,'red',[side*.26,.24,0],Math.PI/2);add(upper,'red',[0,.24,side*.26]);}
 for(const x of[-.26,.26])for(const z of[-.26,.26])add(block(.15,.10,.15),'red',[x,.29,z]);
 const cap=new T.BoxGeometry(1.05,.12,.15,3,1,1);for(const z of[-.26,.26])add(cap,'red',[0,.43,z]);add(new T.BoxGeometry(.15,.12,.78,1,1,3),'wood',[0,.43,0]);
 return{parts,resources,info213:{revision:'scene08-fine-two-stage-crossed-dou213-r05',envelopeWidth:1.05,lowerBase:-.14,upperPlane:.49,fineArmThickness:.155,physicalCarvedWaists:true,visualAccepted:false}};
}
