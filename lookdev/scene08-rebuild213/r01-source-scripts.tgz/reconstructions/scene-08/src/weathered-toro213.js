import * as T from 'three';
export const REBUILD213_REVISION='scene08-weathered-toro-layered-banks213-r01';

const hash=(x,y,z=0)=>{const a=Math.sin(x*127.1+y*311.7+z*74.7+213.6)*43758.5453;return a-Math.floor(a);};
function noise(x,y,z){const a=Math.floor(x),b=Math.floor(y),c=Math.floor(z),f=[x-a,y-b,z-c].map(t=>t*t*(3-2*t)),mix=T.MathUtils.lerp;return mix(mix(mix(hash(a,b,c),hash(a+1,b,c),f[0]),mix(hash(a,b+1,c),hash(a+1,b+1,c),f[0]),f[1]),mix(mix(hash(a,b,c+1),hash(a+1,b,c+1),f[0]),mix(hash(a,b+1,c+1),hash(a+1,b+1,c+1),f[0]),f[1]),f[2]);}

// Coordinate-continuous displacement keeps duplicate seam vertices together.
// The same mineral colour field follows the actual stone, never a view image.
function age(g,seed=0,wear=.008){
 const p=g.attributes.position,uv=[],colors=[];
 for(let i=0;i<p.count;i++){
  const x=p.getX(i),y=p.getY(i),z=p.getZ(i),q=noise(x*14+seed,y*14,z*14),r=noise(x*47,y*47+seed,z*47);
  p.setXYZ(i,x+wear*(noise(x*19+9,y*19,z*19)-.5),y+wear*(q-.5)+wear*.28*(r-.5),z+wear*(noise(x*17,y*17,z*17+13)-.5));
  const broad=noise(x*4+seed,y*3.8,z*4),speck=noise(x*39,y*39,z*39),tone=.55+.33*broad+.17*speck,lichen=T.MathUtils.smoothstep(noise(x*9+seed,y*9,z*9),.64,.79);
  colors.push(tone*(1-.10*lichen),tone*(1-.015*lichen),tone*(1-.22*lichen));uv.push(x*1.10+z*.31,y*1.10);
 }
 g.setAttribute('uv',new T.Float32BufferAttribute(uv,2));g.setAttribute('color',new T.Float32BufferAttribute(colors,3));g.computeVertexNormals();const out=g.index?g.toNonIndexed():g;if(out!==g)g.dispose();const v=out.attributes.position,t=out.attributes.uv;
 for(let i=0;i<v.count;i+=3){const a=new T.Vector3().fromBufferAttribute(v,i),b=new T.Vector3().fromBufferAttribute(v,i+1),c=new T.Vector3().fromBufferAttribute(v,i+2),n=b.sub(a).cross(c.sub(a)).normalize(),up=Math.abs(n.y)>.55,side=Math.abs(n.x)>Math.abs(n.z);for(let k=0;k<3;k++)t.setXY(i+k,(up?v.getX(i+k):side?v.getZ(i+k):v.getX(i+k))*1.1,(up?v.getZ(i+k):v.getY(i+k))*1.1);}
 out.computeBoundingBox();out.userData={...out.userData,authoredWeatheredSolid213:true,metricTriangleUVs:true};return out;
}
function course(profile,sides=64,seed=1){
 const pts=[];for(let j=0;j+1<profile.length;j++)for(let k=0;k<5;k++){const t=k/5;pts.push(new T.Vector2(T.MathUtils.lerp(profile[j][0],profile[j+1][0],t),T.MathUtils.lerp(profile[j][1],profile[j+1][1],t)));}pts.push(new T.Vector2(...profile.at(-1)));
 return age(new T.LatheGeometry(pts,sides),seed,.010);
}
function stoneBlock(w,h,d,seed){
 const g=new T.BoxGeometry(w,h,d,12,14,12),p=g.attributes.position,r=Math.min(.018,w*.08,h*.08,d*.08),half=[w/2-r,h/2-r,d/2-r];
 for(let i=0;i<p.count;i++){const v=new T.Vector3().fromBufferAttribute(p,i),c=new T.Vector3(T.MathUtils.clamp(v.x,-half[0],half[0]),T.MathUtils.clamp(v.y,-half[1],half[1]),T.MathUtils.clamp(v.z,-half[2],half[2]));v.sub(c).normalize().multiplyScalar(r).add(c);p.setXYZ(i,v.x,v.y,v.z);}return age(g,seed,.009);
}
function roof(){
 const W=.76,D=.70,N=84,pp=[],ix=[],uv=[],at=(x,z)=>{const u=x/W,v=z/D,t=Math.max(Math.abs(u),Math.abs(v)),corner=Math.min(Math.abs(u),Math.abs(v));return 2.54+.33*Math.pow(Math.max(0,1-t),1.30)+.074*Math.pow(t,8)*(.13+.87*Math.pow(corner,6));};
 const add=(x,y,z)=>{const i=pp.length/3;pp.push(x,y,z);uv.push(x,z);return i;};
 for(let layer=0;layer<2;layer++)for(let j=0;j<=N;j++)for(let i=0;i<=N;i++){const x=-W+2*W*i/N,z=-D+2*D*j/N;add(x,at(x,z)-(layer?.145:0),z);}
 const S=(N+1)*(N+1);for(let j=0;j<N;j++)for(let i=0;i<N;i++){const a=j*(N+1)+i,b=a+1,c=a+N+1,d=c+1;ix.push(a,c,b,b,c,d,a+S,b+S,c+S,b+S,d+S,c+S);}
 const edge=[];for(let i=0;i<N;i++)edge.push(i);for(let j=0;j<N;j++)edge.push(j*(N+1)+N);for(let i=N;i>0;i--)edge.push(N*(N+1)+i);for(let j=N;j>0;j--)edge.push(j*(N+1));
 for(let k=0;k<edge.length;k++){const a=edge[k],b=edge[(k+1)%edge.length],ids=[a,b,b+S,a+S].map(v=>add(pp[v*3],pp[v*3+1],pp[v*3+2]));ix.push(ids[0],ids[1],ids[2],ids[0],ids[2],ids[3]);}
 const g=new T.BufferGeometry();g.setAttribute('position',new T.Float32BufferAttribute(pp,3));g.setAttribute('uv',new T.Float32BufferAttribute(uv,2));g.setIndex(ix);return age(g,41,.012);
}
function mossOn(geometry){
 const p=geometry.attributes.position,n=geometry.attributes.normal,ix=geometry.index,pp=[],cc=[];
 const vertex=(v,c)=>{pp.push(...v);cc.push(...c);};
 for(let k=0,N=ix?.count??p.count;k<N;k+=12){const ids=[0,1,2].map(i=>ix?ix.getX(k+i):k+i),c=new T.Vector3();for(const i of ids)c.add(new T.Vector3().fromBufferAttribute(p,i));c.multiplyScalar(1/3);const normal=new T.Vector3();for(const i of ids)normal.add(new T.Vector3().fromBufferAttribute(n,i));normal.normalize();
  if(normal.y<.32||noise(c.x*7+3,c.y*4,c.z*7)<.48||c.y<2.56)continue;
  const h=.004+.010*hash(k,7),tip=c.clone().addScaledVector(normal,h),base=ids.map(i=>new T.Vector3().fromBufferAttribute(p,i).addScaledVector(normal,.002)),shade=.70+.25*hash(k,11),color=[shade*.58,shade,shade*.38];
  for(let j=0;j<3;j++){vertex(base[j].toArray(),color);vertex(base[(j+1)%3].toArray(),color);vertex(tip.toArray(),color);}for(const i of[2,1,0])vertex(base[i].toArray(),color);
 }
 const g=new T.BufferGeometry();g.setAttribute('position',new T.Float32BufferAttribute(pp,3));g.setAttribute('color',new T.Float32BufferAttribute(cc,3));g.computeVertexNormals();return g;
}

export function createWeatheredToro213({materials,ownedMaterials,ownedTextures}){
 const source=materials.carvedstone,maps=[source.map,source.normalMap,source.roughnessMap].map(t=>{const q=t.clone();q.repeat.set(1,1);q.needsUpdate=true;ownedTextures.push(q);return q;}),stone=new T.MeshStandardMaterial({name:'scene08-213-cut-and-pitted-pale-granite',color:0xd2d0bf,map:maps[0],normalMap:maps[1],normalScale:new T.Vector2(.62,.62),roughnessMap:maps[2],roughness:.98,vertexColors:true}),damp=stone.clone(),moss=new T.MeshStandardMaterial({name:'scene08-213-solid-moss-cushions',color:0x566339,roughness:1,vertexColors:true}),metal=new T.MeshStandardMaterial({name:'scene08-213-oxidised-chamber-grille',color:0x353122,roughness:.81,metalness:.36}),paper=materials.lanternamber.clone();damp.name='scene08-213-damp-granite-kasa';damp.color.setHex(0xa8ad91);paper.name='scene08-213-recessed-stone-lamp-paper';paper.emissiveIntensity=.27;ownedMaterials.push(stone,damp,moss,metal,paper);
 const foot=course([[0,0],[.43,0],[.49,.05],[.49,.12],[.45,.21],[.34,.27],[0,.27]],8,2),shaft=[];
 for(let j=0;j<3;j++){const lo=.255+j*.36,hi=lo+.354;shaft.push(course([[0,lo],[.218,lo],[.230,lo+.04],[.227,hi-.025],[.214,hi],[0,hi]],48,8+j));}
 const collar=course([[0,1.31],[.24,1.31],[.31,1.36],[.40,1.42],[.45,1.49],[.42,1.55],[0,1.55]],48,13),bowl=course([[0,1.50],[.40,1.50],[.52,1.55],[.57,1.66],[.57,1.72],[.53,1.78],[0,1.78]],8,17),sill=stoneBlock(.94,.095,.90,21),pier=stoneBlock(.13,.655,.13,23),lintel=stoneBlock(.97,.11,.93,27),kasa=roof(),mossGeo=mossOn(kasa),neck=course([[0,2.85],[.14,2.85],[.17,2.90],[.16,2.95],[.105,2.99],[0,2.99]],48,31),ball=age(new T.SphereGeometry(.173,56,36).translate(0,3.158,0),37,.013),petal=age(new T.SphereGeometry(1,16,12),7,.014),builds=[];
 function build(api,x,z,y,scale){const{group,emit,box}=api;group(x,y,z,.08,()=>{
  emit(foot,stone);for(const g of shaft)emit(g,stone);emit(collar,stone);emit(bowl,stone);emit(sill,stone,0,1.805,0);emit(lintel,stone,0,2.43,0);
  for(const xx of[-.37,.37])for(const zz of[-.35,.35])emit(pier,stone,xx,2.095,zz);
  for(let face=0;face<4;face++)group(0,0,0,face*Math.PI/2,()=>{
   box(0,2.10,.333,.56,.52,.009,paper);for(const xx of[-.27,.27])box(xx,2.10,.379,.022,.57,.022,metal);for(const yy of[1.825,2.375])box(0,yy,.379,.56,.022,.022,metal);
   for(const xx of[-.18,0,.18])box(xx,2.10,.385,.011,.52,.015,metal);for(const yy of[1.94,2.10,2.26])box(0,yy,.386,.54,.010,.015,metal);
  });
  for(let j=0;j<12;j++){const a=j*Math.PI/6;emit(petal,stone,Math.sin(a)*.425,1.435,Math.cos(a)*.425,.105,.068,.042,[0,a,0]);}
  emit(kasa,damp);emit(mossGeo,moss);emit(neck,stone);emit(ball,stone);
 },scale);builds.push({anchor:[x,y,z],scale,singleCrownSphere:true,localHeight:3.34,capThickness:.145,chamberClearHeight:.52,closedHollowChamber:true});}
 return{build,info:{revision:'scene08-reference-led-weathered-toro213-r01',builds,source:'Authored closed stone geometry, same independent CC0 granite scans; comparison photograph never sampled',originalStackedBulbsRetired:true,newExternalAssets:false,visualAccepted:false}};
}
