import * as T from 'three';

// Authored bounded linear reflectances. These are ordinary non-emissive PBR
// finishes on existing construction, not image light or brighter paper.
export function installMaterialHierarchy191(mats,materials,peony){
 const metal={gold:{rgb:[1,.766,.336],metalness:.91,roughness:.38},oldgold:{rgb:[.55,.34,.12],metalness:.82,roughness:.53},joinerygilt:{rgb:[.78,.52,.18],metalness:.78,roughness:.50},hardwarebrass:{rgb:[.72,.49,.17],metalness:.86,roughness:.47}};
 for(const [name,s]of Object.entries(metal)){const m=mats[name];m.color.setRGB(...s.rgb);m.metalness=s.metalness;m.roughness=s.roughness;m.emissive.setRGB(0,0,0);m.emissiveIntensity=0;}
 const lacquer=[];
 for(const [name,coat,coatRough]of[['red',.18,.38],['redlight',.12,.42],['wood',.10,.46]]){
  const old=mats[name],m=new T.MeshPhysicalMaterial({name:old.name+'-satin191',color:old.color.clone(),map:old.map,normalMap:old.normalMap,normalScale:old.normalScale.clone(),roughnessMap:old.roughnessMap,roughness:old.roughness,metalness:0,clearcoat:coat,clearcoatRoughness:coatRough,envMapIntensity:old.envMapIntensity});
  m.onBeforeCompile=old.onBeforeCompile;m.customProgramCacheKey=old.customProgramCacheKey;materials.push(m);mats[name]=m;lacquer.push({name,clearcoat:coat,clearcoatRoughness:coatRough,existingPortablePigmentAndNormalRoughnessRetained:true});
 }
 peony.material.color.setRGB(.65,.43,.14);peony.material.emissive.setRGB(0,0,0);peony.material.emissiveIntensity=0;
 const nearNames=[];for(const name of['gold','oldgold','hardwarebrass','hardwareRecess','joinerygilt']){const old=mats[name],m=old.clone();m.name='scene08-entry-court-reflection191-'+name;m.onBeforeCompile=old.onBeforeCompile;m.customProgramCacheKey=old.customProgramCacheKey;materials.push(m);mats['entry191_'+name]=m;nearNames.push('entry191_'+name);}
 return{revision:'scene08-nonemissive-metal-lacquer-hierarchy191-r03',metal,lacquer,nearNames,peonyRaisedLinearReflectance:[.65,.43,.14],geometryChanged:false,paperEmissionChanged:false,architectureEmissionAdded:false,reflectanceBounds:[0,1],visualAccepted:false};
}

// Actual native linear scene capture, invoked only by the official renderer
// while it owns the FIFO. This is neither a painted environment nor a bake
// from the comparison photograph. Only entry-court metal receives this probe.
export function captureEntryCourt191({renderer,scene,mats,stream}){
 const target=new T.WebGLCubeRenderTarget(128,{type:T.HalfFloatType,generateMipmaps:false}),probe=new T.CubeCamera(.12,120,target);probe.position.set(-.65,3.0,7.05);probe.name='scene08-191-actual-entry-court-radiance';scene.add(probe);
 const mirrorVisible=stream.visible,auto=renderer.shadowMap.autoUpdate;stream.visible=false;renderer.shadowMap.autoUpdate=false;renderer.shadowMap.needsUpdate=true;
 const pmrem=new T.PMREMGenerator(renderer);let env;
 try{scene.updateMatrixWorld(true);probe.update(renderer,scene);env=pmrem.fromCubemap(target.texture);}
 finally{stream.visible=mirrorVisible;renderer.shadowMap.autoUpdate=auto;probe.removeFromParent();target.dispose();pmrem.dispose();}
 const names=[];for(const key of Object.keys(mats).filter(k=>k.startsWith('entry191_'))){const m=mats[key];m.envMap=env.texture;m.envMapRotation.set(0,0,0);m.envMapIntensity=.82;m.needsUpdate=true;names.push(key);}
 return{info:{revision:'scene08-actual-entry-court-probe191-r03',position:probe.position.toArray(),resolution:128,targets:names,linearNativeSceneCapture:true,referenceImageSampled:false,architectureAndSkyAndExistingLightsCaptured:true,mirrorHiddenOnlyDuringCapture:true,exposedTowerUsesOriginalOutdoorSky:true,envGain:.82,visualAccepted:false},dispose(){env.dispose();}};
}
