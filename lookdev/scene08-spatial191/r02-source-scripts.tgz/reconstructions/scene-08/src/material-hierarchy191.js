import * as T from 'three';

// Authored bounded linear reflectances. These are ordinary non-emissive PBR
// finishes on existing construction, not image light or brighter paper.
export function installMaterialHierarchy191(mats,materials,peony){
 const metal={gold:{rgb:[1,.766,.336],metalness:.91,roughness:.38},oldgold:{rgb:[.55,.34,.12],metalness:.82,roughness:.53},joinerygilt:{rgb:[.78,.52,.18],metalness:.78,roughness:.50},hardwarebrass:{rgb:[.72,.49,.17],metalness:.86,roughness:.47}};
 for(const [name,s]of Object.entries(metal)){const m=mats[name];m.color.setRGB(...s.rgb);m.metalness=s.metalness;m.roughness=s.roughness;m.emissive.setRGB(0,0,0);m.emissiveIntensity=0;}
 const lacquer=[];
 for(const [name,coat,coatRough]of[['red',.18,.38],['redlight',.12,.42],['wood',.10,.46]]){
  const old=mats[name],m=new T.MeshPhysicalMaterial({name:old.name+'-satin191',color:old.color.clone(),map:old.map,normalMap:old.normalMap,normalScale:old.normalScale.clone(),roughnessMap:old.roughnessMap,roughness:old.roughness,metalness:0,clearcoat:coat,clearcoatRoughness:coatRough,envMapIntensity:old.envMapIntensity});
  m.onBeforeCompile=old.onBeforeCompile;m.customProgramCacheKey=old.customProgramCacheKey;materials.push(m);mats[name]=m;lacquer.push({name,clearcoat:coat,clearcoatRoughness:coatRough,existingPortablePigmentAndNormalRoughnessRetained:true});
 }
 peony.material.color.setRGB(.65,.43,.14);peony.material.emissive.setRGB(0,0,0);peony.material.emissiveIntensity=0;
 return{revision:'scene08-nonemissive-metal-lacquer-hierarchy191-r02',metal,lacquer,peonyRaisedLinearReflectance:[.65,.43,.14],geometryChanged:false,paperEmissionChanged:false,architectureEmissionAdded:false,reflectanceBounds:[0,1],visualAccepted:false};
}
